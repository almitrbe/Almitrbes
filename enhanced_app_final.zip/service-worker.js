// Service Worker for PWA Support
const CACHE_NAME = 'project-expenses-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/css/styles.css',
  '/css/themes.css',
  '/css/animations.css',
  '/js/app.js',
  '/js/data.js',
  '/js/ui.js',
  '/js/export.js',
  '/js/ai.js',
  '/js/charts.js',
  'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.18.0/dist/tf.min.js',
  'https://cdn.jsdelivr.net/npm/chart.js',
  'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js'
];

// Install event - cache assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(ASSETS_TO_CACHE);
      })
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Cache hit - return response
        if (response) {
          return response;
        }
        
        // Clone the request
        const fetchRequest = event.request.clone();
        
        return fetch(fetchRequest).then(
          (response) => {
            // Check if valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Clone the response
            const responseToCache = response.clone();
            
            caches.open(CACHE_NAME)
              .then((cache) => {
                // Don't cache API calls or external resources
                if (event.request.url.includes('/api/') || 
                    !event.request.url.startsWith(self.location.origin)) {
                  return;
                }
                cache.put(event.request, responseToCache);
              });
              
            return response;
          }
        );
      })
      .catch(() => {
        // If both cache and network fail, show offline page
        if (event.request.mode === 'navigate') {
          return caches.match('/offline.html');
        }
      })
  );
});

// Background sync for offline data
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-expenses') {
    event.waitUntil(syncExpenses());
  } else if (event.tag === 'sync-projects') {
    event.waitUntil(syncProjects());
  }
});

// Push notification support
self.addEventListener('push', (event) => {
  const data = event.data.json();
  const options = {
    body: data.body,
    icon: 'assets/icons/icon-192x192.png',
    badge: 'assets/icons/badge-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: '1',
      url: data.url || '/'
    },
    actions: [
      {
        action: 'explore',
        title: 'عرض التفاصيل',
        icon: 'assets/icons/checkmark.png'
      },
      {
        action: 'close',
        title: 'إغلاق',
        icon: 'assets/icons/xmark.png'
      },
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Notification click event
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow(event.notification.data.url)
    );
  }
});

// Helper function to sync expenses when back online
async function syncExpenses() {
  try {
    const db = await openDatabase();
    const offlineExpenses = await db.getAll('offlineExpenses');
    
    if (offlineExpenses.length === 0) {
      return;
    }
    
    // Process offline expenses
    for (const expense of offlineExpenses) {
      // In a real app, you would send this to your server
      console.log('Syncing expense:', expense);
      
      // After successful sync, remove from offline storage
      await db.delete('offlineExpenses', expense.id);
    }
    
    // Notify the user
    self.registration.showNotification('مزامنة المصروفات', {
      body: `تمت مزامنة ${offlineExpenses.length} من المصروفات بنجاح`,
      icon: 'assets/icons/icon-192x192.png'
    });
    
  } catch (error) {
    console.error('Error syncing expenses:', error);
  }
}

// Helper function to sync projects when back online
async function syncProjects() {
  try {
    const db = await openDatabase();
    const offlineProjects = await db.getAll('offlineProjects');
    
    if (offlineProjects.length === 0) {
      return;
    }
    
    // Process offline projects
    for (const project of offlineProjects) {
      // In a real app, you would send this to your server
      console.log('Syncing project:', project);
      
      // After successful sync, remove from offline storage
      await db.delete('offlineProjects', project.id);
    }
    
    // Notify the user
    self.registration.showNotification('مزامنة المشاريع', {
      body: `تمت مزامنة ${offlineProjects.length} من المشاريع بنجاح`,
      icon: 'assets/icons/icon-192x192.png'
    });
    
  } catch (error) {
    console.error('Error syncing projects:', error);
  }
}

// Helper function to open IndexedDB
function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('ProjectExpensesDB', 1);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const db = request.result;
      resolve({
        getAll: (storeName) => {
          return new Promise((resolve, reject) => {
            const transaction = db.transaction(storeName, 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.getAll();
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
          });
        },
        delete: (storeName, id) => {
          return new Promise((resolve, reject) => {
            const transaction = db.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.delete(id);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve();
          });
        }
      });
    };
    
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('offlineExpenses')) {
        db.createObjectStore('offlineExpenses', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('offlineProjects')) {
        db.createObjectStore('offlineProjects', { keyPath: 'id' });
      }
    };
  });
}
