/**
 * export.js - نظام تصدير البيانات المتقدم
 * يدعم تصدير البيانات إلى Excel وPDF مع خيارات تخصيص متقدمة
 */

class ExportManager {
  constructor(dataManager) {
    this.dataManager = dataManager;
    this.exportThemes = {
      default: {
        fontFamily: 'Cairo, sans-serif',
        headerBgColor: '#2196F3',
        headerTextColor: '#ffffff',
        borderColor: '#dddddd',
        accentColor: '#2196F3',
        logoText: 'إدارة مصروفات المشاريع'
      },
      modern: {
        fontFamily: 'Cairo, sans-serif',
        headerBgColor: '#673AB7',
        headerTextColor: '#ffffff',
        borderColor: '#eeeeee',
        accentColor: '#FF4081',
        logoText: 'نظام إدارة المصروفات'
      },
      minimal: {
        fontFamily: 'Cairo, sans-serif',
        headerBgColor: '#212121',
        headerTextColor: '#ffffff',
        borderColor: '#f5f5f5',
        accentColor: '#757575',
        logoText: 'تقرير المصروفات'
      }
    };
    
    // تهيئة المكتبات الخارجية
    this.initLibraries();
  }
  
  /**
   * تهيئة المكتبات الخارجية
   */
  async initLibraries() {
    try {
      // التحقق من وجود XLSX
      if (typeof XLSX === 'undefined') {
        await this.loadScript('https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js');
      }
      
      // التحقق من وجود jsPDF
      if (typeof jspdf === 'undefined') {
        await this.loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
      }
      
      // التحقق من وجود html2canvas
      if (typeof html2canvas === 'undefined') {
        await this.loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js');
      }
      
      console.log('تم تهيئة مكتبات التصدير بنجاح');
    } catch (error) {
      console.error('خطأ في تهيئة مكتبات التصدير:', error);
    }
  }
  
  /**
   * تحميل سكريبت خارجي
   */
  loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`فشل تحميل السكريبت: ${src}`));
      document.head.appendChild(script);
    });
  }
  
  /**
   * تصدير مشروع إلى Excel
   */
  async exportProjectToExcel(projectId, options = {}) {
    try {
      // التحقق من وجود XLSX
      if (typeof XLSX === 'undefined') {
        throw new Error('مكتبة XLSX غير متوفرة');
      }
      
      // الحصول على بيانات المشروع
      const project = this.dataManager.getProject(projectId);
      if (!project) {
        throw new Error('المشروع غير موجود');
      }
      
      const expenses = this.dataManager.getExpenses(projectId);
      
      // تحضير البيانات
      const data = this.prepareExcelData(project, expenses, options);
      
      // إنشاء مصنف عمل
      const wb = XLSX.utils.book_new();
      
      // إضافة ورقة عمل للمعلومات العامة
      const wsInfo = XLSX.utils.aoa_to_sheet(data.info);
      XLSX.utils.book_append_sheet(wb, wsInfo, 'معلومات المشروع');
      
      // إضافة ورقة عمل للمصروفات
      const wsExpenses = XLSX.utils.aoa_to_sheet(data.expenses);
      XLSX.utils.book_append_sheet(wb, wsExpenses, 'المصروفات');
      
      // إضافة ورقة عمل للإحصائيات إذا كان مطلوباً
      if (options.includeStats) {
        const wsStats = XLSX.utils.aoa_to_sheet(data.stats);
        XLSX.utils.book_append_sheet(wb, wsStats, 'الإحصائيات');
      }
      
      // تعيين خصائص المصنف
      wb.Props = {
        Title: `تقرير مشروع ${project.name}`,
        Subject: 'تقرير مصروفات',
        Author: 'نظام إدارة مصروفات المشاريع',
        CreatedDate: new Date()
      };
      
      // تصدير المصنف
      const fileName = `مشروع_${project.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.xlsx`;
      XLSX.writeFile(wb, fileName);
      
      return {
        success: true,
        fileName,
        message: 'تم تصدير البيانات بنجاح'
      };
    } catch (error) {
      console.error('خطأ في تصدير المشروع إلى Excel:', error);
      throw new Error('فشل تصدير البيانات إلى Excel: ' + error.message);
    }
  }
  
  /**
   * تحضير بيانات Excel
   */
  prepareExcelData(project, expenses, options) {
    // حساب الإحصائيات
    const totalCapital = expenses
      .filter(expense => expense.type === 'capital')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
    
    const totalExpenses = expenses
      .filter(expense => expense.type === 'expense')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
    
    const remaining = totalCapital - totalExpenses;
    
    // معلومات المشروع
    const info = [
      ['تقرير مشروع', project.name],
      ['تاريخ البدء', this.formatDate(project.date)],
      ['تاريخ التقرير', this.formatDate(new Date().toISOString())],
      [''],
      ['الملخص المالي'],
      ['رأس المال', totalCapital.toFixed(2)],
      ['المصروفات', totalExpenses.toFixed(2)],
      ['المتبقي', remaining.toFixed(2)],
      ['نسبة الاستخدام', totalCapital > 0 ? ((totalExpenses / totalCapital) * 100).toFixed(2) + '%' : '0%'],
      [''],
      ['تم إنشاء هذا التقرير بواسطة نظام إدارة مصروفات المشاريع'],
      ['حقوق النشر محفوظة لـ hashem almatariy - 774889958']
    ];
    
    // بيانات المصروفات
    const expenses_data = [
      ['النوع', 'التاريخ', 'المبلغ', 'الوصف'] // رأس الجدول
    ];
    
    // ترتيب المصروفات حسب التاريخ (الأحدث أولاً)
    const sortedExpenses = [...expenses].sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // إضافة بيانات المصروفات
    sortedExpenses.forEach(expense => {
      expenses_data.push([
        expense.type === 'capital' ? 'رأس مال' : 'مصروف',
        this.formatDate(expense.date),
        parseFloat(expense.amount).toFixed(2),
        expense.desc || '-'
      ]);
    });
    
    // بيانات الإحصائيات
    const stats = [
      ['إحصائيات المشروع'],
      [''],
      ['توزيع المصروفات حسب النوع'],
      ['النوع', 'العدد', 'المبلغ الإجمالي', 'النسبة المئوية']
    ];
    
    // حساب توزيع المصروفات حسب النوع
    const expensesByType = {
      'capital': { count: 0, total: 0 },
      'expense': { count: 0, total: 0 }
    };
    
    expenses.forEach(expense => {
      expensesByType[expense.type].count++;
      expensesByType[expense.type].total += parseFloat(expense.amount);
    });
    
    // إضافة بيانات توزيع المصروفات
    stats.push(
      ['رأس مال', expensesByType.capital.count, expensesByType.capital.total.toFixed(2), 
       ((expensesByType.capital.total / (totalCapital + totalExpenses)) * 100).toFixed(2) + '%'],
      ['مصروف', expensesByType.expense.count, expensesByType.expense.total.toFixed(2), 
       ((expensesByType.expense.total / (totalCapital + totalExpenses)) * 100).toFixed(2) + '%']
    );
    
    // إضافة توزيع المصروفات حسب الشهر
    stats.push(
      [''],
      ['توزيع المصروفات حسب الشهر'],
      ['الشهر', 'رأس المال', 'المصروفات', 'الرصيد']
    );
    
    // حساب توزيع المصروفات حسب الشهر
    const expensesByMonth = {};
    
    expenses.forEach(expense => {
      const date = new Date(expense.date);
      const monthKey = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
      
      if (!expensesByMonth[monthKey]) {
        expensesByMonth[monthKey] = {
          capital: 0,
          expense: 0
        };
      }
      
      expensesByMonth[monthKey][expense.type] += parseFloat(expense.amount);
    });
    
    // إضافة بيانات توزيع المصروفات حسب الشهر
    Object.keys(expensesByMonth).sort().forEach(monthKey => {
      const monthData = expensesByMonth[monthKey];
      const balance = monthData.capital - monthData.expense;
      
      stats.push([
        this.formatMonthYear(monthKey),
        monthData.capital.toFixed(2),
        monthData.expense.toFixed(2),
        balance.toFixed(2)
      ]);
    });
    
    return {
      info,
      expenses: expenses_data,
      stats
    };
  }
  
  /**
   * تصدير مشروع إلى PDF
   */
  async exportProjectToPDF(projectId, options = {}) {
    try {
      // التحقق من وجود jsPDF
      if (typeof jspdf === 'undefined') {
        throw new Error('مكتبة jsPDF غير متوفرة');
      }
      
      // التحقق من وجود html2canvas
      if (typeof html2canvas === 'undefined') {
        throw new Error('مكتبة html2canvas غير متوفرة');
      }
      
      // الحصول على بيانات المشروع
      const project = this.dataManager.getProject(projectId);
      if (!project) {
        throw new Error('المشروع غير موجود');
      }
      
      const expenses = this.dataManager.getExpenses(projectId);
      
      // تحضير البيانات
      const data = this.preparePDFData(project, expenses, options);
      
      // إنشاء عنصر HTML مؤقت للتقرير
      const reportContainer = document.createElement('div');
      reportContainer.id = 'pdf-report-container';
      reportContainer.style.width = '800px';
      reportContainer.style.padding = '20px';
      reportContainer.style.fontFamily = data.theme.fontFamily;
      reportContainer.style.direction = 'rtl';
      reportContainer.style.position = 'absolute';
      reportContainer.style.left = '-9999px';
      reportContainer.style.top = '0';
      reportContainer.style.backgroundColor = '#ffffff';
      
      // إضافة محتوى التقرير
      reportContainer.innerHTML = data.html;
      
      // إضافة العنصر إلى الصفحة
      document.body.appendChild(reportContainer);
      
      // إنشاء ملف PDF
      const { jsPDF } = jspdf;
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      // تحويل HTML إلى صورة
      const canvas = await html2canvas(reportContainer, {
        scale: 2,
        useCORS: true,
        logging: false
      });
      
      // إضافة الصورة إلى PDF
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 0;
      
      pdf.addImage(imgData, 'JPEG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      
      // إضافة صفحات إضافية إذا كان المحتوى طويلاً
      if (imgHeight * ratio > pdfHeight) {
        let heightLeft = imgHeight * ratio;
        let position = 0;
        
        heightLeft -= pdfHeight;
        position = -pdfHeight;
        
        while (heightLeft > 0) {
          position -= pdfHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'JPEG', imgX, position, imgWidth * ratio, imgHeight * ratio);
          heightLeft -= pdfHeight;
        }
      }
      
      // إزالة العنصر المؤقت
      document.body.removeChild(reportContainer);
      
      // تصدير PDF
      const fileName = `مشروع_${project.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
      pdf.save(fileName);
      
      return {
        success: true,
        fileName,
        message: 'تم تصدير البيانات بنجاح'
      };
    } catch (error) {
      console.error('خطأ في تصدير المشروع إلى PDF:', error);
      throw new Error('فشل تصدير البيانات إلى PDF: ' + error.message);
    }
  }
  
  /**
   * تحضير بيانات PDF
   */
  preparePDFData(project, expenses, options) {
    // الحصول على السمة
    const theme = this.exportThemes[options.theme] || this.exportThemes.default;
    
    // حساب الإحصائيات
    const totalCapital = expenses
      .filter(expense => expense.type === 'capital')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
    
    const totalExpenses = expenses
      .filter(expense => expense.type === 'expense')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
    
    const remaining = totalCapital - totalExpenses;
    const utilizationRate = totalCapital > 0 ? ((totalExpenses / totalCapital) * 100).toFixed(2) : 0;
    
    // ترتيب المصروفات حسب التاريخ (الأحدث أولاً)
    const sortedExpenses = [...expenses].sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // إنشاء HTML للتقرير
    let html = `
      <style>
        body {
          font-family: ${theme.fontFamily};
          direction: rtl;
          color: #333;
        }
        .report-header {
          background-color: ${theme.headerBgColor};
          color: ${theme.headerTextColor};
          padding: 20px;
          text-align: center;
          border-radius: 5px;
          margin-bottom: 20px;
        }
        .report-title {
          margin: 0;
          font-size: 24px;
        }
        .report-subtitle {
          margin: 5px 0 0;
          font-size: 16px;
          opacity: 0.8;
        }
        .report-date {
          margin: 5px 0 0;
          font-size: 14px;
          opacity: 0.7;
        }
        .report-section {
          margin-bottom: 30px;
        }
        .section-title {
          color: ${theme.accentColor};
          border-bottom: 2px solid ${theme.accentColor};
          padding-bottom: 5px;
          margin-bottom: 15px;
        }
        .summary-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 15px;
          margin-bottom: 20px;
        }
        .summary-item {
          background-color: #f9f9f9;
          padding: 15px;
          border-radius: 5px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .summary-label {
          font-size: 14px;
          color: #666;
          margin-bottom: 5px;
        }
        .summary-value {
          font-size: 18px;
          font-weight: bold;
          color: #333;
        }
        .summary-value.positive {
          color: #4CAF50;
        }
        .summary-value.negative {
          color: #F44336;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        th, td {
          padding: 10px;
          text-align: right;
          border: 1px solid ${theme.borderColor};
        }
        th {
          background-color: ${theme.headerBgColor};
          color: ${theme.headerTextColor};
        }
        tr:nth-child(even) {
          background-color: #f9f9f9;
        }
        .capital {
          color: #4CAF50;
        }
        .expense {
          color: #F44336;
        }
        .footer {
          margin-top: 30px;
          text-align: center;
          font-size: 12px;
          color: #666;
          border-top: 1px solid #eee;
          padding-top: 10px;
        }
        .copyright {
          margin-top: 5px;
          font-weight: bold;
        }
      </style>
      
      <div class="report-header">
        <h1 class="report-title">تقرير مشروع: ${project.name}</h1>
        <p class="report-subtitle">${theme.logoText}</p>
        <p class="report-date">تاريخ التقرير: ${this.formatDate(new Date().toISOString())}</p>
      </div>
      
      <div class="report-section">
        <h2 class="section-title">معلومات المشروع</h2>
        <div class="summary-grid">
          <div class="summary-item">
            <div class="summary-label">اسم المشروع</div>
            <div class="summary-value">${project.name}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">تاريخ البدء</div>
            <div class="summary-value">${this.formatDate(project.date)}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">رأس المال</div>
            <div class="summary-value positive">${totalCapital.toFixed(2)} ريال</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">المصروفات</div>
            <div class="summary-value expense">${totalExpenses.toFixed(2)} ريال</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">المتبقي</div>
            <div class="summary-value ${remaining >= 0 ? 'positive' : 'negative'}">${remaining.toFixed(2)} ريال</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">نسبة الاستخدام</div>
            <div class="summary-value">${utilizationRate}%</div>
          </div>
        </div>
      </div>
      
      <div class="report-section">
        <h2 class="section-title">المصروفات</h2>
        <table>
          <thead>
            <tr>
              <th>النوع</th>
              <th>التاريخ</th>
              <th>المبلغ</th>
              <th>الوصف</th>
            </tr>
          </thead>
          <tbody>
    `;
    
    // إضافة بيانات المصروفات
    sortedExpenses.forEach(expense => {
      html += `
        <tr>
          <td class="${expense.type}">${expense.type === 'capital' ? 'رأس مال' : 'مصروف'}</td>
          <td>${this.formatDate(expense.date)}</td>
          <td>${parseFloat(expense.amount).toFixed(2)} ريال</td>
          <td>${expense.desc || '-'}</td>
        </tr>
      `;
    });
    
    html += `
          </tbody>
        </table>
      </div>
    `;
    
    // إضافة قسم الإحصائيات إذا كان مطلوباً
    if (options.includeStats) {
      // حساب توزيع المصروفات حسب النوع
      const expensesByType = {
        'capital': { count: 0, total: 0 },
        'expense': { count: 0, total: 0 }
      };
      
      expenses.forEach(expense => {
        expensesByType[expense.type].count++;
        expensesByType[expense.type].total += parseFloat(expense.amount);
      });
      
      // حساب توزيع المصروفات حسب الشهر
      const expensesByMonth = {};
      
      expenses.forEach(expense => {
        const date = new Date(expense.date);
        const monthKey = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
        
        if (!expensesByMonth[monthKey]) {
          expensesByMonth[monthKey] = {
            capital: 0,
            expense: 0
          };
        }
        
        expensesByMonth[monthKey][expense.type] += parseFloat(expense.amount);
      });
      
      html += `
        <div class="report-section">
          <h2 class="section-title">الإحصائيات</h2>
          
          <h3>توزيع المصروفات حسب النوع</h3>
          <table>
            <thead>
              <tr>
                <th>النوع</th>
                <th>العدد</th>
                <th>المبلغ الإجمالي</th>
                <th>النسبة المئوية</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="capital">رأس مال</td>
                <td>${expensesByType.capital.count}</td>
                <td>${expensesByType.capital.total.toFixed(2)} ريال</td>
                <td>${((expensesByType.capital.total / (totalCapital + totalExpenses)) * 100).toFixed(2)}%</td>
              </tr>
              <tr>
                <td class="expense">مصروف</td>
                <td>${expensesByType.expense.count}</td>
                <td>${expensesByType.expense.total.toFixed(2)} ريال</td>
                <td>${((expensesByType.expense.total / (totalCapital + totalExpenses)) * 100).toFixed(2)}%</td>
              </tr>
            </tbody>
          </table>
          
          <h3>توزيع المصروفات حسب الشهر</h3>
          <table>
            <thead>
              <tr>
                <th>الشهر</th>
                <th>رأس المال</th>
                <th>المصروفات</th>
                <th>الرصيد</th>
              </tr>
            </thead>
            <tbody>
      `;
      
      // إضافة بيانات توزيع المصروفات حسب الشهر
      Object.keys(expensesByMonth).sort().forEach(monthKey => {
        const monthData = expensesByMonth[monthKey];
        const balance = monthData.capital - monthData.expense;
        
        html += `
          <tr>
            <td>${this.formatMonthYear(monthKey)}</td>
            <td class="capital">${monthData.capital.toFixed(2)} ريال</td>
            <td class="expense">${monthData.expense.toFixed(2)} ريال</td>
            <td class="${balance >= 0 ? 'positive' : 'negative'}">${balance.toFixed(2)} ريال</td>
          </tr>
        `;
      });
      
      html += `
            </tbody>
          </table>
        </div>
      `;
    }
    
    // إضافة تذييل التقرير
    html += `
      <div class="footer">
        <p>تم إنشاء هذا التقرير بواسطة نظام إدارة مصروفات المشاريع</p>
        <p class="copyright">حقوق النشر محفوظة لـ hashem almatariy - 774889958</p>
      </div>
    `;
    
    return {
      html,
      theme
    };
  }
  
  /**
   * تنسيق التاريخ
   */
  formatDate(dateString) {
    if (!dateString) return '';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('ar-SA');
    } catch (e) {
      return dateString;
    }
  }
  
  /**
   * تنسيق الشهر والسنة
   */
  formatMonthYear(monthKey) {
    const [year, month] = monthKey.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, 1);
    
    const monthNames = [
      'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    return `${monthNames[date.getMonth()]} ${date.getFullYear()}`;
  }
}

// تصدير الفئة
window.ExportManager = ExportManager;
