/**
 * ai.js - نظام الذكاء الاصطناعي للتنبؤ وتحليل المصروفات
 * يستخدم TensorFlow.js للتنبؤ بالمصروفات المستقبلية واكتشاف الأنماط
 */

class AIManager {
  constructor(dataManager) {
    this.dataManager = dataManager;
    this.model = null;
    this.isModelReady = false;
    this.predictionHistory = [];
    
    // تهيئة TensorFlow
    this.initTensorFlow();
  }
  
  /**
   * تهيئة TensorFlow والتحقق من توفره
   */
  async initTensorFlow() {
    try {
      // التحقق من وجود TensorFlow.js
      if (typeof tf === 'undefined') {
        await this.loadScript('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.18.0/dist/tf.min.js');
      }
      
      console.log('تم تهيئة TensorFlow.js بنجاح');
    } catch (error) {
      console.error('خطأ في تهيئة TensorFlow.js:', error);
    }
  }
  
  /**
   * تحميل سكريبت خارجي
   */
  loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`فشل تحميل السكريبت: ${src}`));
      document.head.appendChild(script);
    });
  }
  
  /**
   * إنشاء وتدريب نموذج التنبؤ
   */
  async trainModel(projectId) {
    try {
      if (typeof tf === 'undefined') {
        throw new Error('TensorFlow.js غير متوفر');
      }
      
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      if (!expenses || expenses.length < 10) {
        throw new Error('لا توجد بيانات كافية للتدريب (يجب أن يكون هناك 10 مصروفات على الأقل)');
      }
      
      // تحضير البيانات
      const { inputs, outputs, dates } = this.prepareData(expenses);
      
      // إنشاء النموذج
      this.model = tf.sequential();
      
      // إضافة طبقات النموذج
      this.model.add(tf.layers.dense({
        units: 10,
        activation: 'relu',
        inputShape: [inputs[0].length]
      }));
      
      this.model.add(tf.layers.dense({
        units: 5,
        activation: 'relu'
      }));
      
      this.model.add(tf.layers.dense({
        units: 1,
        activation: 'linear'
      }));
      
      // تجميع النموذج
      this.model.compile({
        optimizer: tf.train.adam(0.01),
        loss: 'meanSquaredError',
        metrics: ['mse']
      });
      
      // تحويل البيانات إلى تنسورات
      const xs = tf.tensor2d(inputs);
      const ys = tf.tensor2d(outputs.map(o => [o]));
      
      // تدريب النموذج
      const history = await this.model.fit(xs, ys, {
        epochs: 100,
        batchSize: 8,
        validationSplit: 0.2,
        callbacks: {
          onEpochEnd: (epoch, logs) => {
            if (epoch % 10 === 0) {
              console.log(`Epoch ${epoch}: loss = ${logs.loss.toFixed(4)}`);
            }
          }
        }
      });
      
      // تنظيف الذاكرة
      xs.dispose();
      ys.dispose();
      
      this.isModelReady = true;
      console.log('تم تدريب النموذج بنجاح');
      
      return {
        success: true,
        finalLoss: history.history.loss[history.history.loss.length - 1],
        epochs: history.params.epochs
      };
    } catch (error) {
      console.error('خطأ في تدريب النموذج:', error);
      this.isModelReady = false;
      throw new Error('فشل تدريب النموذج: ' + error.message);
    }
  }
  
  /**
   * تحضير البيانات للتدريب
   */
  prepareData(expenses) {
    // فلترة المصروفات (استبعاد رأس المال)
    const filteredExpenses = expenses.filter(e => e.type === 'expense');
    
    // ترتيب المصروفات حسب التاريخ
    filteredExpenses.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // تجميع المصروفات حسب التاريخ
    const expensesByDate = {};
    filteredExpenses.forEach(expense => {
      const date = expense.date.split('T')[0]; // استخراج التاريخ فقط
      if (!expensesByDate[date]) {
        expensesByDate[date] = 0;
      }
      expensesByDate[date] += parseFloat(expense.amount);
    });
    
    // تحويل البيانات إلى مصفوفات
    const dates = Object.keys(expensesByDate).sort();
    const amounts = dates.map(date => expensesByDate[date]);
    
    // إنشاء ميزات الإدخال (آخر 7 أيام) والإخراج (اليوم التالي)
    const windowSize = 7;
    const inputs = [];
    const outputs = [];
    const outputDates = [];
    
    for (let i = windowSize; i < amounts.length; i++) {
      const input = amounts.slice(i - windowSize, i);
      inputs.push(input);
      outputs.push(amounts[i]);
      outputDates.push(dates[i]);
    }
    
    return { inputs, outputs, dates: outputDates };
  }
  
  /**
   * التنبؤ بالمصروفات المستقبلية
   */
  async predictFutureExpenses(projectId, days = 7) {
    try {
      if (!this.isModelReady || !this.model) {
        await this.trainModel(projectId);
      }
      
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      
      // تحضير البيانات
      const { inputs, outputs, dates } = this.prepareData(expenses);
      
      if (inputs.length === 0) {
        throw new Error('لا توجد بيانات كافية للتنبؤ');
      }
      
      // استخدام آخر 7 أيام للتنبؤ
      let lastInput = inputs[inputs.length - 1];
      const predictions = [];
      const predictionDates = [];
      
      // تحديد تاريخ البداية للتنبؤ (اليوم التالي لآخر تاريخ)
      let lastDate = new Date(dates[dates.length - 1]);
      
      for (let i = 0; i < days; i++) {
        // التنبؤ باليوم التالي
        const inputTensor = tf.tensor2d([lastInput]);
        const prediction = this.model.predict(inputTensor);
        const predictedValue = prediction.dataSync()[0];
        
        // تنظيف الذاكرة
        inputTensor.dispose();
        prediction.dispose();
        
        // حساب التاريخ التالي
        lastDate.setDate(lastDate.getDate() + 1);
        const nextDate = lastDate.toISOString().split('T')[0];
        
        // تخزين التنبؤ
        predictions.push(Math.max(0, predictedValue)); // ضمان أن القيمة ليست سالبة
        predictionDates.push(nextDate);
        
        // تحديث الإدخال للتنبؤ التالي
        lastInput = [...lastInput.slice(1), predictedValue];
      }
      
      // تخزين نتائج التنبؤ
      const result = {
        projectId,
        timestamp: new Date().toISOString(),
        predictions: predictionDates.map((date, i) => ({
          date,
          amount: this.roundToTwo(predictions[i])
        }))
      };
      
      this.predictionHistory.push(result);
      
      return result;
    } catch (error) {
      console.error('خطأ في التنبؤ بالمصروفات المستقبلية:', error);
      throw new Error('فشل التنبؤ: ' + error.message);
    }
  }
  
  /**
   * اكتشاف أنماط الإنفاق غير العادية
   */
  detectAnomalies(projectId, threshold = 2) {
    try {
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      if (!expenses || expenses.length < 5) {
        throw new Error('لا توجد بيانات كافية لاكتشاف الأنماط (يجب أن يكون هناك 5 مصروفات على الأقل)');
      }
      
      // فلترة المصروفات (استبعاد رأس المال)
      const filteredExpenses = expenses.filter(e => e.type === 'expense');
      
      // حساب المتوسط والانحراف المعياري
      const amounts = filteredExpenses.map(e => parseFloat(e.amount));
      const mean = this.calculateMean(amounts);
      const stdDev = this.calculateStdDev(amounts, mean);
      
      // اكتشاف القيم الشاذة (أكبر من المتوسط + threshold * الانحراف المعياري)
      const anomalies = filteredExpenses.filter(expense => {
        const amount = parseFloat(expense.amount);
        const zScore = Math.abs((amount - mean) / stdDev);
        return zScore > threshold;
      });
      
      return {
        projectId,
        mean: this.roundToTwo(mean),
        stdDev: this.roundToTwo(stdDev),
        threshold,
        anomalies: anomalies.map(a => ({
          id: a.id,
          date: a.date,
          amount: parseFloat(a.amount),
          desc: a.desc,
          zScore: this.roundToTwo(Math.abs((parseFloat(a.amount) - mean) / stdDev))
        }))
      };
    } catch (error) {
      console.error('خطأ في اكتشاف أنماط الإنفاق غير العادية:', error);
      throw new Error('فشل اكتشاف الأنماط: ' + error.message);
    }
  }
  
  /**
   * تحليل اتجاهات المصروفات
   */
  analyzeExpenseTrends(projectId) {
    try {
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      if (!expenses || expenses.length < 5) {
        throw new Error('لا توجد بيانات كافية لتحليل الاتجاهات (يجب أن يكون هناك 5 مصروفات على الأقل)');
      }
      
      // فلترة المصروفات (استبعاد رأس المال)
      const filteredExpenses = expenses.filter(e => e.type === 'expense');
      
      // ترتيب المصروفات حسب التاريخ
      filteredExpenses.sort((a, b) => new Date(a.date) - new Date(b.date));
      
      // تجميع المصروفات حسب التاريخ
      const expensesByDate = {};
      filteredExpenses.forEach(expense => {
        const date = expense.date.split('T')[0]; // استخراج التاريخ فقط
        if (!expensesByDate[date]) {
          expensesByDate[date] = 0;
        }
        expensesByDate[date] += parseFloat(expense.amount);
      });
      
      // تحويل البيانات إلى مصفوفات
      const dates = Object.keys(expensesByDate).sort();
      const amounts = dates.map(date => expensesByDate[date]);
      
      // حساب المتوسط المتحرك (7 أيام)
      const movingAverage = this.calculateMovingAverage(amounts, 7);
      
      // حساب معدل النمو
      const growthRate = this.calculateGrowthRate(amounts);
      
      // تحديد الاتجاه (تصاعدي، تنازلي، مستقر)
      let trend = 'مستقر';
      if (growthRate > 0.05) {
        trend = 'تصاعدي';
      } else if (growthRate < -0.05) {
        trend = 'تنازلي';
      }
      
      // تحديد أيام الذروة
      const peakDays = this.findPeakDays(dates, amounts);
      
      return {
        projectId,
        trend,
        growthRate: this.roundToTwo(growthRate * 100), // تحويل إلى نسبة مئوية
        averageDailyExpense: this.roundToTwo(this.calculateMean(amounts)),
        peakDays,
        data: dates.map((date, i) => ({
          date,
          amount: amounts[i],
          movingAverage: movingAverage[i] || null
        }))
      };
    } catch (error) {
      console.error('خطأ في تحليل اتجاهات المصروفات:', error);
      throw new Error('فشل تحليل الاتجاهات: ' + error.message);
    }
  }
  
  /**
   * اقتراحات ذكية لتوفير المال
   */
  generateSavingSuggestions(projectId) {
    try {
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      if (!expenses || expenses.length < 5) {
        throw new Error('لا توجد بيانات كافية لتوليد اقتراحات (يجب أن يكون هناك 5 مصروفات على الأقل)');
      }
      
      // تحليل الاتجاهات
      const trends = this.analyzeExpenseTrends(projectId);
      
      // اكتشاف الأنماط غير العادية
      const anomalies = this.detectAnomalies(projectId);
      
      // توليد الاقتراحات
      const suggestions = [];
      
      // اقتراح 1: تقليل المصروفات في أيام الذروة
      if (trends.peakDays.length > 0) {
        suggestions.push({
          type: 'peak_days',
          title: 'تقليل المصروفات في أيام الذروة',
          description: `لاحظنا أن مصروفاتك تزداد في أيام معينة (${trends.peakDays.map(d => d.dayName).join('، ')}). حاول تخطيط مصروفاتك بشكل أفضل في هذه الأيام.`,
          potentialSaving: this.roundToTwo(trends.peakDays.reduce((sum, day) => sum + day.averageAmount * 0.2, 0))
        });
      }
      
      // اقتراح 2: تجنب المصروفات غير العادية
      if (anomalies.anomalies.length > 0) {
        suggestions.push({
          type: 'anomalies',
          title: 'تجنب المصروفات غير العادية',
          description: `وجدنا ${anomalies.anomalies.length} مصروفات غير عادية تتجاوز المتوسط بشكل كبير. حاول تجنب هذه المصروفات الاستثنائية في المستقبل.`,
          potentialSaving: this.roundToTwo(anomalies.anomalies.reduce((sum, a) => sum + (a.amount - anomalies.mean) * 0.7, 0))
        });
      }
      
      // اقتراح 3: تحسين الاتجاه العام
      if (trends.trend === 'تصاعدي') {
        suggestions.push({
          type: 'trend',
          title: 'عكس اتجاه زيادة المصروفات',
          description: `مصروفاتك في ازدياد بمعدل ${trends.growthRate}% تقريباً. حاول تقليل المصروفات اليومية للحفاظ على ميزانيتك.`,
          potentialSaving: this.roundToTwo(trends.averageDailyExpense * 0.1 * 30) // توفير 10% شهرياً
        });
      }
      
      // اقتراح 4: توزيع المصروفات بشكل أفضل
      suggestions.push({
        type: 'distribution',
        title: 'توزيع المصروفات بشكل أفضل',
        description: 'حاول توزيع مصروفاتك بشكل متساوٍ على مدار الشهر بدلاً من تركيزها في فترات معينة.',
        potentialSaving: this.roundToTwo(trends.averageDailyExpense * 0.05 * 30) // توفير 5% شهرياً
      });
      
      return {
        projectId,
        totalPotentialSaving: this.roundToTwo(suggestions.reduce((sum, s) => sum + s.potentialSaving, 0)),
        suggestions
      };
    } catch (error) {
      console.error('خطأ في توليد اقتراحات التوفير:', error);
      throw new Error('فشل توليد الاقتراحات: ' + error.message);
    }
  }
  
  /**
   * حساب المتوسط
   */
  calculateMean(values) {
    return values.reduce((sum, value) => sum + value, 0) / values.length;
  }
  
  /**
   * حساب الانحراف المعياري
   */
  calculateStdDev(values, mean) {
    if (!mean) {
      mean = this.calculateMean(values);
    }
    
    const squaredDifferences = values.map(value => Math.pow(value - mean, 2));
    const variance = this.calculateMean(squaredDifferences);
    return Math.sqrt(variance);
  }
  
  /**
   * حساب المتوسط المتحرك
   */
  calculateMovingAverage(values, windowSize) {
    const result = [];
    
    for (let i = 0; i < values.length; i++) {
      if (i < windowSize - 1) {
        result.push(null); // لا يوجد متوسط متحرك للقيم الأولى
      } else {
        const windowValues = values.slice(i - windowSize + 1, i + 1);
        result.push(this.calculateMean(windowValues));
      }
    }
    
    return result;
  }
  
  /**
   * حساب معدل النمو
   */
  calculateGrowthRate(values) {
    if (values.length < 2) {
      return 0;
    }
    
    // استخدام الانحدار الخطي البسيط لحساب معدل النمو
    const n = values.length;
    const x = Array.from({ length: n }, (_, i) => i); // [0, 1, 2, ...]
    
    const sumX = x.reduce((sum, val) => sum + val, 0);
    const sumY = values.reduce((sum, val) => sum + val, 0);
    const sumXY = x.reduce((sum, val, i) => sum + val * values[i], 0);
    const sumXX = x.reduce((sum, val) => sum + val * val, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    // حساب معدل النمو كنسبة من القيمة الأولية
    return slope / (intercept || 1);
  }
  
  /**
   * العثور على أيام الذروة
   */
  findPeakDays(dates, amounts) {
    // تحويل التواريخ إلى أيام الأسبوع
    const dayNames = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const dayIndices = dates.map(date => new Date(date).getDay());
    
    // حساب متوسط المصروفات لكل يوم من أيام الأسبوع
    const dayTotals = Array(7).fill(0);
    const dayCounts = Array(7).fill(0);
    
    for (let i = 0; i < dates.length; i++) {
      const dayIndex = dayIndices[i];
      dayTotals[dayIndex] += amounts[i];
      dayCounts[dayIndex]++;
    }
    
    const dayAverages = dayTotals.map((total, i) => 
      dayCounts[i] > 0 ? total / dayCounts[i] : 0
    );
    
    // حساب المتوسط العام
    const overallAverage = this.calculateMean(amounts);
    
    // تحديد أيام الذروة (أيام تتجاوز المتوسط العام بنسبة 20%)
    const peakDays = [];
    for (let i = 0; i < 7; i++) {
      if (dayCounts[i] > 0 && dayAverages[i] > overallAverage * 1.2) {
        peakDays.push({
          day: i,
          dayName: dayNames[i],
          averageAmount: this.roundToTwo(dayAverages[i]),
          ratio: this.roundToTwo(dayAverages[i] / overallAverage)
        });
      }
    }
    
    return peakDays.sort((a, b) => b.averageAmount - a.averageAmount);
  }
  
  /**
   * تقريب الرقم إلى رقمين عشريين
   */
  roundToTwo(num) {
    return Math.round((num + Number.EPSILON) * 100) / 100;
  }
}

// تصدير الفئة
window.AIManager = AIManager;
