/**
 * charts.js - نظام الرسوم البيانية المتقدمة
 * يستخدم Chart.js لإنشاء رسوم بيانية تفاعلية وجذابة
 */

class ChartsManager {
  constructor(dataManager) {
    this.dataManager = dataManager;
    this.charts = {};
    this.chartColors = {
      primary: 'rgba(33, 150, 243, 0.7)',
      primaryBorder: 'rgba(33, 150, 243, 1)',
      accent: 'rgba(255, 64, 129, 0.7)',
      accentBorder: 'rgba(255, 64, 129, 1)',
      success: 'rgba(76, 175, 80, 0.7)',
      successBorder: 'rgba(76, 175, 80, 1)',
      warning: 'rgba(255, 193, 7, 0.7)',
      warningBorder: 'rgba(255, 193, 7, 1)',
      danger: 'rgba(244, 67, 54, 0.7)',
      dangerBorder: 'rgba(244, 67, 54, 1)'
    };
    
    // تهيئة Chart.js
    this.initChartJs();
  }
  
  /**
   * تهيئة Chart.js والتحقق من توفره
   */
  async initChartJs() {
    try {
      // التحقق من وجود Chart.js
      if (typeof Chart === 'undefined') {
        await this.loadScript('https://cdn.jsdelivr.net/npm/chart.js');
      }
      
      // تعيين الخيارات العامة
      Chart.defaults.font.family = "'Cairo', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
      Chart.defaults.color = '#666';
      Chart.defaults.plugins.tooltip.rtl = true;
      Chart.defaults.plugins.legend.rtl = true;
      
      console.log('تم تهيئة Chart.js بنجاح');
    } catch (error) {
      console.error('خطأ في تهيئة Chart.js:', error);
    }
  }
  
  /**
   * تحميل سكريبت خارجي
   */
  loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`فشل تحميل السكريبت: ${src}`));
      document.head.appendChild(script);
    });
  }
  
  /**
   * إنشاء رسم بياني للمصروفات حسب التاريخ
   */
  createExpensesByDateChart(projectId, containerId) {
    try {
      if (typeof Chart === 'undefined') {
        throw new Error('Chart.js غير متوفر');
      }
      
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      if (!expenses || expenses.length === 0) {
        throw new Error('لا توجد بيانات للعرض');
      }
      
      // تجميع المصروفات حسب التاريخ
      const expensesByDate = this.groupExpensesByDate(expenses);
      const capitalByDate = this.groupCapitalByDate(expenses);
      
      // تحويل البيانات إلى مصفوفات
      const dates = Object.keys(expensesByDate).sort();
      const expenseAmounts = dates.map(date => expensesByDate[date] || 0);
      const capitalAmounts = dates.map(date => capitalByDate[date] || 0);
      
      // حساب الرصيد التراكمي
      const balanceAmounts = this.calculateCumulativeBalance(dates, capitalAmounts, expenseAmounts);
      
      // الحصول على عنصر الرسم البياني
      const container = document.getElementById(containerId);
      if (!container) {
        throw new Error(`لم يتم العثور على العنصر: ${containerId}`);
      }
      
      // إنشاء عنصر canvas
      const canvas = document.createElement('canvas');
      container.innerHTML = '';
      container.appendChild(canvas);
      
      // إنشاء الرسم البياني
      const ctx = canvas.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: dates.map(date => this.formatDate(date)),
          datasets: [
            {
              label: 'المصروفات',
              data: expenseAmounts,
              backgroundColor: this.chartColors.danger,
              borderColor: this.chartColors.dangerBorder,
              borderWidth: 1,
              order: 2
            },
            {
              label: 'رأس المال',
              data: capitalAmounts,
              backgroundColor: this.chartColors.success,
              borderColor: this.chartColors.successBorder,
              borderWidth: 1,
              order: 3
            },
            {
              label: 'الرصيد التراكمي',
              data: balanceAmounts,
              type: 'line',
              fill: false,
              backgroundColor: this.chartColors.primaryBorder,
              borderColor: this.chartColors.primaryBorder,
              borderWidth: 2,
              pointRadius: 3,
              pointBackgroundColor: this.chartColors.primaryBorder,
              tension: 0.4,
              order: 1,
              yAxisID: 'y1'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'top',
              labels: {
                font: {
                  size: 12
                }
              }
            },
            title: {
              display: true,
              text: 'المصروفات ورأس المال حسب التاريخ',
              font: {
                size: 16,
                weight: 'bold'
              }
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function(context) {
                  let label = context.dataset.label || '';
                  if (label) {
                    label += ': ';
                  }
                  if (context.parsed.y !== null) {
                    label += context.parsed.y.toFixed(2) + ' ريال';
                  }
                  return label;
                }
              }
            }
          },
          scales: {
            x: {
              title: {
                display: true,
                text: 'التاريخ'
              }
            },
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'المبلغ (ريال)'
              }
            },
            y1: {
              position: 'right',
              beginAtZero: false,
              title: {
                display: true,
                text: 'الرصيد التراكمي (ريال)'
              },
              grid: {
                drawOnChartArea: false
              }
            }
          }
        }
      });
      
      // تخزين مرجع الرسم البياني
      this.charts[containerId] = chart;
      
      return chart;
    } catch (error) {
      console.error('خطأ في إنشاء رسم بياني للمصروفات حسب التاريخ:', error);
      throw new Error('فشل إنشاء الرسم البياني: ' + error.message);
    }
  }
  
  /**
   * إنشاء رسم بياني دائري لتوزيع المصروفات
   */
  createExpenseDistributionChart(projectId, containerId) {
    try {
      if (typeof Chart === 'undefined') {
        throw new Error('Chart.js غير متوفر');
      }
      
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      if (!expenses || expenses.length === 0) {
        throw new Error('لا توجد بيانات للعرض');
      }
      
      // فلترة المصروفات (استبعاد رأس المال)
      const filteredExpenses = expenses.filter(e => e.type === 'expense');
      if (filteredExpenses.length === 0) {
        throw new Error('لا توجد مصروفات للعرض');
      }
      
      // تجميع المصروفات حسب الوصف
      const expensesByDesc = {};
      filteredExpenses.forEach(expense => {
        const desc = expense.desc || 'بدون وصف';
        if (!expensesByDesc[desc]) {
          expensesByDesc[desc] = 0;
        }
        expensesByDesc[desc] += parseFloat(expense.amount);
      });
      
      // تحويل البيانات إلى مصفوفات
      const descriptions = Object.keys(expensesByDesc);
      const amounts = descriptions.map(desc => expensesByDesc[desc]);
      
      // إنشاء ألوان عشوائية
      const backgroundColors = this.generateRandomColors(descriptions.length);
      
      // الحصول على عنصر الرسم البياني
      const container = document.getElementById(containerId);
      if (!container) {
        throw new Error(`لم يتم العثور على العنصر: ${containerId}`);
      }
      
      // إنشاء عنصر canvas
      const canvas = document.createElement('canvas');
      container.innerHTML = '';
      container.appendChild(canvas);
      
      // إنشاء الرسم البياني
      const ctx = canvas.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: descriptions,
          datasets: [{
            data: amounts,
            backgroundColor: backgroundColors,
            borderColor: 'rgba(255, 255, 255, 0.8)',
            borderWidth: 2,
            hoverOffset: 10
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'right',
              labels: {
                font: {
                  size: 12
                }
              }
            },
            title: {
              display: true,
              text: 'توزيع المصروفات',
              font: {
                size: 16,
                weight: 'bold'
              }
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const label = context.label || '';
                  const value = context.parsed || 0;
                  const total = context.dataset.data.reduce((a, b) => a + b, 0);
                  const percentage = ((value / total) * 100).toFixed(1);
                  return `${label}: ${value.toFixed(2)} ريال (${percentage}%)`;
                }
              }
            }
          }
        }
      });
      
      // تخزين مرجع الرسم البياني
      this.charts[containerId] = chart;
      
      return chart;
    } catch (error) {
      console.error('خطأ في إنشاء رسم بياني دائري لتوزيع المصروفات:', error);
      throw new Error('فشل إنشاء الرسم البياني: ' + error.message);
    }
  }
  
  /**
   * إنشاء رسم بياني للتنبؤ بالمصروفات المستقبلية
   */
  createExpensePredictionChart(projectId, containerId, predictions) {
    try {
      if (typeof Chart === 'undefined') {
        throw new Error('Chart.js غير متوفر');
      }
      
      // الحصول على بيانات المشروع
      const expenses = this.dataManager.getExpenses(projectId);
      if (!expenses || expenses.length === 0) {
        throw new Error('لا توجد بيانات للعرض');
      }
      
      // تجميع المصروفات الفعلية حسب التاريخ
      const expensesByDate = this.groupExpensesByDate(expenses);
      
      // تحويل البيانات إلى مصفوفات
      const actualDates = Object.keys(expensesByDate).sort();
      const actualAmounts = actualDates.map(date => expensesByDate[date] || 0);
      
      // تحضير بيانات التنبؤ
      const predictionDates = predictions.map(p => p.date);
      const predictionAmounts = predictions.map(p => p.amount);
      
      // الحصول على عنصر الرسم البياني
      const container = document.getElementById(containerId);
      if (!container) {
        throw new Error(`لم يتم العثور على العنصر: ${containerId}`);
      }
      
      // إنشاء عنصر canvas
      const canvas = document.createElement('canvas');
      container.innerHTML = '';
      container.appendChild(canvas);
      
      // إنشاء الرسم البياني
      const ctx = canvas.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: [...actualDates, ...predictionDates].map(date => this.formatDate(date)),
          datasets: [
            {
              label: 'المصروفات الفعلية',
              data: [...actualAmounts, ...Array(predictionDates.length).fill(null)],
              backgroundColor: this.chartColors.primary,
              borderColor: this.chartColors.primaryBorder,
              borderWidth: 2,
              pointRadius: 4,
              pointBackgroundColor: this.chartColors.primaryBorder,
              tension: 0.4,
              fill: false
            },
            {
              label: 'التنبؤ بالمصروفات',
              data: [...Array(actualDates.length).fill(null), ...predictionAmounts],
              backgroundColor: this.chartColors.accent,
              borderColor: this.chartColors.accentBorder,
              borderWidth: 2,
              pointRadius: 4,
              pointBackgroundColor: this.chartColors.accentBorder,
              borderDash: [5, 5],
              tension: 0.4,
              fill: false
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'top',
              labels: {
                font: {
                  size: 12
                }
              }
            },
            title: {
              display: true,
              text: 'التنبؤ بالمصروفات المستقبلية',
              font: {
                size: 16,
                weight: 'bold'
              }
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function(context) {
                  let label = context.dataset.label || '';
                  if (label) {
                    label += ': ';
                  }
                  if (context.parsed.y !== null) {
                    label += context.parsed.y.toFixed(2) + ' ريال';
                  }
                  return label;
                }
              }
            }
          },
          scales: {
            x: {
              title: {
                display: true,
                text: 'التاريخ'
              }
            },
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'المبلغ (ريال)'
              }
            }
          }
        }
      });
      
      // تخزين مرجع الرسم البياني
      this.charts[containerId] = chart;
      
      return chart;
    } catch (error) {
      console.error('خطأ في إنشاء رسم بياني للتنبؤ بالمصروفات المستقبلية:', error);
      throw new Error('فشل إنشاء الرسم البياني: ' + error.message);
    }
  }
  
  /**
   * إنشاء رسم بياني لمقارنة المشاريع
   */
  createProjectComparisonChart(containerId, projectIds) {
    try {
      if (typeof Chart === 'undefined') {
        throw new Error('Chart.js غير متوفر');
      }
      
      if (!projectIds || projectIds.length === 0) {
        throw new Error('لم يتم تحديد مشاريع للمقارنة');
      }
      
      // تحضير بيانات المشاريع
      const projectsData = [];
      
      for (const projectId of projectIds) {
        const project = this.dataManager.getProject(projectId);
        if (!project) {
          console.warn(`المشروع غير موجود: ${projectId}`);
          continue;
        }
        
        const expenses = this.dataManager.getExpenses(projectId);
        const totalCapital = this.calculateTotalCapital(expenses);
        const totalExpenses = this.calculateTotalExpenses(expenses);
        const remaining = totalCapital - totalExpenses;
        
        projectsData.push({
          id: projectId,
          name: project.name,
          totalCapital,
          totalExpenses,
          remaining,
          utilizationRate: totalCapital > 0 ? (totalExpenses / totalCapital) * 100 : 0
        });
      }
      
      if (projectsData.length === 0) {
        throw new Error('لا توجد بيانات صالحة للمقارنة');
      }
      
      // الحصول على عنصر الرسم البياني
      const container = document.getElementById(containerId);
      if (!container) {
        throw new Error(`لم يتم العثور على العنصر: ${containerId}`);
      }
      
      // إنشاء عنصر canvas
      const canvas = document.createElement('canvas');
      container.innerHTML = '';
      container.appendChild(canvas);
      
      // تحضير البيانات للرسم البياني
      const projectNames = projectsData.map(p => p.name);
      const capitalData = projectsData.map(p => p.totalCapital);
      const expensesData = projectsData.map(p => p.totalExpenses);
      const remainingData = projectsData.map(p => p.remaining);
      const utilizationRates = projectsData.map(p => p.utilizationRate);
      
      // إنشاء الرسم البياني
      const ctx = canvas.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: projectNames,
          datasets: [
            {
              label: 'رأس المال',
              data: capitalData,
              backgroundColor: this.chartColors.success,
              borderColor: this.chartColors.successBorder,
              borderWidth: 1
            },
            {
              label: 'المصروفات',
              data: expensesData,
              backgroundColor: this.chartColors.danger,
              borderColor: this.chartColors.dangerBorder,
              borderWidth: 1
            },
            {
              label: 'المتبقي',
              data: remainingData,
              backgroundColor: this.chartColors.primary,
              borderColor: this.chartColors.primaryBorder,
              borderWidth: 1
            },
            {
              label: 'نسبة الاستخدام (%)',
              data: utilizationRates,
              type: 'line',
              backgroundColor: this.chartColors.warning,
              borderColor: this.chartColors.warningBorder,
              borderWidth: 2,
              pointRadius: 5,
              pointBackgroundColor: this.chartColors.warningBorder,
              fill: false,
              yAxisID: 'y1'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'top',
              labels: {
                font: {
                  size: 12
                }
              }
            },
            title: {
              display: true,
              text: 'مقارنة المشاريع',
              font: {
                size: 16,
                weight: 'bold'
              }
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function(context) {
                  let label = context.dataset.label || '';
                  if (label) {
                    label += ': ';
                  }
                  if (context.parsed.y !== null) {
                    if (label.includes('نسبة')) {
                      label += context.parsed.y.toFixed(1) + '%';
                    } else {
                      label += context.parsed.y.toFixed(2) + ' ريال';
                    }
                  }
                  return label;
                }
              }
            }
          },
          scales: {
            x: {
              title: {
                display: true,
                text: 'المشاريع'
              }
            },
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'المبلغ (ريال)'
              }
            },
            y1: {
              position: 'right',
              beginAtZero: true,
              max: 100,
              title: {
                display: true,
                text: 'نسبة الاستخدام (%)'
              },
              grid: {
                drawOnChartArea: false
              }
            }
          }
        }
      });
      
      // تخزين مرجع الرسم البياني
      this.charts[containerId] = chart;
      
      return chart;
    } catch (error) {
      console.error('خطأ في إنشاء رسم بياني لمقارنة المشاريع:', error);
      throw new Error('فشل إنشاء الرسم البياني: ' + error.message);
    }
  }
  
  /**
   * إنشاء لوحة معلومات تفاعلية
   */
  createDashboard(containerId, projectId) {
    try {
      // الحصول على عنصر لوحة المعلومات
      const container = document.getElementById(containerId);
      if (!container) {
        throw new Error(`لم يتم العثور على العنصر: ${containerId}`);
      }
      
      // الحصول على بيانات المشروع
      const project = this.dataManager.getProject(projectId);
      if (!project) {
        throw new Error('المشروع غير موجود');
      }
      
      const expenses = this.dataManager.getExpenses(projectId);
      
      // حساب الإحصائيات
      const totalCapital = this.calculateTotalCapital(expenses);
      const totalExpenses = this.calculateTotalExpenses(expenses);
      const remaining = totalCapital - totalExpenses;
      const utilizationRate = totalCapital > 0 ? (totalExpenses / totalCapital) * 100 : 0;
      
      // إنشاء هيكل لوحة المعلومات
      container.innerHTML = `
        <div class="dashboard">
          <div class="dashboard-header">
            <h2>لوحة معلومات المشروع: ${project.name}</h2>
            <p class="dashboard-date">تاريخ البدء: ${this.formatDate(project.date)}</p>
          </div>
          
          <div class="dashboard-stats">
            <div class="stat-card capital">
              <div class="stat-icon">💰</div>
              <div class="stat-title">رأس المال</div>
              <div class="stat-value">${totalCapital.toFixed(2)} ريال</div>
            </div>
            
            <div class="stat-card expenses">
              <div class="stat-icon">💸</div>
              <div class="stat-title">المصروفات</div>
              <div class="stat-value">${totalExpenses.toFixed(2)} ريال</div>
            </div>
            
            <div class="stat-card remaining">
              <div class="stat-icon">💼</div>
              <div class="stat-title">المتبقي</div>
              <div class="stat-value">${remaining.toFixed(2)} ريال</div>
            </div>
            
            <div class="stat-card utilization">
              <div class="stat-icon">📊</div>
              <div class="stat-title">نسبة الاستخدام</div>
              <div class="stat-value">${utilizationRate.toFixed(1)}%</div>
              <div class="progress-bar">
                <div class="progress" style="width: ${Math.min(100, utilizationRate)}%;"></div>
              </div>
            </div>
          </div>
          
          <div class="dashboard-charts">
            <div class="chart-container">
              <div id="expensesChart" style="height: 300px;"></div>
            </div>
            
            <div class="chart-container">
              <div id="distributionChart" style="height: 300px;"></div>
            </div>
          </div>
          
          <div class="dashboard-footer">
            <p>آخر تحديث: ${new Date().toLocaleString('ar-SA')}</p>
          </div>
        </div>
      `;
      
      // إضافة الأنماط
      const style = document.createElement('style');
      style.textContent = `
        .dashboard {
          background-color: var(--card-bg);
          border-radius: 15px;
          padding: 20px;
          box-shadow: var(--3d-shadow);
        }
        
        .dashboard-header {
          margin-bottom: 20px;
          text-align: center;
        }
        
        .dashboard-date {
          color: var(--text-light);
          font-size: 0.9rem;
        }
        
        .dashboard-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 15px;
          margin-bottom: 30px;
        }
        
        .stat-card {
          background-color: var(--card-bg);
          border-radius: 10px;
          padding: 15px;
          text-align: center;
          box-shadow: 0 4px 6px rgba(0,0,0,0.1);
          position: relative;
          overflow: hidden;
          transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
          transform: translateY(-5px);
        }
        
        .stat-card::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 5px;
        }
        
        .stat-card.capital::before {
          background-color: var(--success);
        }
        
        .stat-card.expenses::before {
          background-color: var(--danger);
        }
        
        .stat-card.remaining::before {
          background-color: var(--primary);
        }
        
        .stat-card.utilization::before {
          background-color: var(--warning);
        }
        
        .stat-icon {
          font-size: 2rem;
          margin-bottom: 10px;
        }
        
        .stat-title {
          font-size: 1rem;
          color: var(--text-light);
          margin-bottom: 5px;
        }
        
        .stat-value {
          font-size: 1.5rem;
          font-weight: bold;
          color: var(--text);
        }
        
        .progress-bar {
          height: 8px;
          background-color: rgba(0,0,0,0.1);
          border-radius: 4px;
          margin-top: 10px;
          overflow: hidden;
        }
        
        .progress {
          height: 100%;
          background-color: var(--warning);
          border-radius: 4px;
        }
        
        .dashboard-charts {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
          gap: 20px;
          margin-bottom: 20px;
        }
        
        .chart-container {
          background-color: var(--card-bg);
          border-radius: 10px;
          padding: 15px;
          box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .dashboard-footer {
          text-align: center;
          color: var(--text-light);
          font-size: 0.8rem;
        }
        
        @media (max-width: 768px) {
          .dashboard-charts {
            grid-template-columns: 1fr;
          }
        }
      `;
      document.head.appendChild(style);
      
      // إنشاء الرسوم البيانية
      this.createExpensesByDateChart(projectId, 'expensesChart');
      this.createExpenseDistributionChart(projectId, 'distributionChart');
      
      return true;
    } catch (error) {
      console.error('خطأ في إنشاء لوحة المعلومات:', error);
      throw new Error('فشل إنشاء لوحة المعلومات: ' + error.message);
    }
  }
  
  /**
   * تحديث رسم بياني
   */
  updateChart(containerId, newData) {
    try {
      const chart = this.charts[containerId];
      if (!chart) {
        throw new Error(`الرسم البياني غير موجود: ${containerId}`);
      }
      
      // تحديث البيانات
      chart.data = { ...chart.data, ...newData };
      chart.update();
      
      return true;
    } catch (error) {
      console.error('خطأ في تحديث الرسم البياني:', error);
      throw new Error('فشل تحديث الرسم البياني: ' + error.message);
    }
  }
  
  /**
   * حذف رسم بياني
   */
  destroyChart(containerId) {
    try {
      const chart = this.charts[containerId];
      if (chart) {
        chart.destroy();
        delete this.charts[containerId];
      }
      
      return true;
    } catch (error) {
      console.error('خطأ في حذف الرسم البياني:', error);
      throw new Error('فشل حذف الرسم البياني: ' + error.message);
    }
  }
  
  /**
   * تجميع المصروفات حسب التاريخ
   */
  groupExpensesByDate(expenses) {
    const expensesByDate = {};
    
    expenses
      .filter(expense => expense.type === 'expense')
      .forEach(expense => {
        const date = expense.date.split('T')[0]; // استخراج التاريخ فقط
        if (!expensesByDate[date]) {
          expensesByDate[date] = 0;
        }
        expensesByDate[date] += parseFloat(expense.amount);
      });
    
    return expensesByDate;
  }
  
  /**
   * تجميع رأس المال حسب التاريخ
   */
  groupCapitalByDate(expenses) {
    const capitalByDate = {};
    
    expenses
      .filter(expense => expense.type === 'capital')
      .forEach(expense => {
        const date = expense.date.split('T')[0]; // استخراج التاريخ فقط
        if (!capitalByDate[date]) {
          capitalByDate[date] = 0;
        }
        capitalByDate[date] += parseFloat(expense.amount);
      });
    
    return capitalByDate;
  }
  
  /**
   * حساب الرصيد التراكمي
   */
  calculateCumulativeBalance(dates, capitalAmounts, expenseAmounts) {
    let balance = 0;
    const balanceAmounts = [];
    
    for (let i = 0; i < dates.length; i++) {
      balance += capitalAmounts[i] - expenseAmounts[i];
      balanceAmounts.push(balance);
    }
    
    return balanceAmounts;
  }
  
  /**
   * حساب إجمالي رأس المال
   */
  calculateTotalCapital(expenses) {
    return expenses
      .filter(expense => expense.type === 'capital')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
  }
  
  /**
   * حساب إجمالي المصروفات
   */
  calculateTotalExpenses(expenses) {
    return expenses
      .filter(expense => expense.type === 'expense')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
  }
  
  /**
   * إنشاء ألوان عشوائية
   */
  generateRandomColors(count) {
    const colors = [];
    const baseColors = [
      'rgba(33, 150, 243, 0.7)',   // أزرق
      'rgba(255, 64, 129, 0.7)',   // وردي
      'rgba(76, 175, 80, 0.7)',    // أخضر
      'rgba(255, 193, 7, 0.7)',    // أصفر
      'rgba(244, 67, 54, 0.7)',    // أحمر
      'rgba(156, 39, 176, 0.7)',   // بنفسجي
      'rgba(0, 188, 212, 0.7)',    // سماوي
      'rgba(255, 152, 0, 0.7)',    // برتقالي
      'rgba(121, 85, 72, 0.7)',    // بني
      'rgba(63, 81, 181, 0.7)'     // نيلي
    ];
    
    // استخدام الألوان الأساسية أولاً
    for (let i = 0; i < Math.min(count, baseColors.length); i++) {
      colors.push(baseColors[i]);
    }
    
    // إنشاء ألوان عشوائية إضافية إذا لزم الأمر
    for (let i = baseColors.length; i < count; i++) {
      const r = Math.floor(Math.random() * 200) + 55;
      const g = Math.floor(Math.random() * 200) + 55;
      const b = Math.floor(Math.random() * 200) + 55;
      colors.push(`rgba(${r}, ${g}, ${b}, 0.7)`);
    }
    
    return colors;
  }
  
  /**
   * تنسيق التاريخ
   */
  formatDate(dateString) {
    if (!dateString) return '';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('ar-SA');
    } catch (e) {
      return dateString;
    }
  }
}

// تصدير الفئة
window.ChartsManager = ChartsManager;
