/**
 * app.js - الملف الرئيسي للتطبيق
 * يقوم بتهيئة وتنسيق جميع مكونات التطبيق
 */

// تهيئة التطبيق عند تحميل الصفحة
window.addEventListener('DOMContentLoaded', initApp);

// كائن التطبيق العام
window.app = {};

/**
 * تهيئة التطبيق
 */
async function initApp() {
  try {
    console.log('بدء تهيئة التطبيق...');
    
    // تسجيل Service Worker للدعم دون اتصال
    registerServiceWorker();
    
    // تهيئة مدير البيانات
    app.data = new DataManager();
    
    // تهيئة مدير التصدير
    app.export = new ExportManager(app.data);
    
    // تهيئة مدير الذكاء الاصطناعي
    app.ai = new AIManager(app.data);
    
    // تهيئة مدير الرسوم البيانية
    app.charts = new ChartsManager(app.data);
    
    // تهيئة مدير واجهة المستخدم
    app.ui = new UIManager(app.data, app.export, app.ai, app.charts);
    
    // بدء تشغيل التطبيق
    await app.ui.init();
    
    console.log('تم تهيئة التطبيق بنجاح');
  } catch (error) {
    console.error('خطأ في تهيئة التطبيق:', error);
    showErrorMessage('خطأ في تهيئة التطبيق', error.message);
  }
}

/**
 * تسجيل Service Worker
 */
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js')
        .then(registration => {
          console.log('تم تسجيل Service Worker بنجاح:', registration.scope);
        })
        .catch(error => {
          console.error('فشل تسجيل Service Worker:', error);
        });
    });
  }
}

/**
 * عرض رسالة خطأ
 */
function showErrorMessage(title, message) {
  // إنشاء عنصر رسالة الخطأ
  const errorElement = document.createElement('div');
  errorElement.className = 'error-message-container';
  errorElement.innerHTML = `
    <div class="error-message">
      <h3>${title}</h3>
      <p>${message}</p>
      <button onclick="location.reload()">إعادة تحميل التطبيق</button>
    </div>
  `;
  
  // إضافة عنصر رسالة الخطأ إلى الصفحة
  document.body.appendChild(errorElement);
}

/**
 * التعامل مع الأخطاء غير المتوقعة
 */
window.onerror = function(message, source, lineno, colno, error) {
  console.error('خطأ غير متوقع:', error);
  
  // عرض رسالة خطأ للمستخدم إذا كان التطبيق قيد التشغيل
  if (app && app.ui) {
    app.ui.showErrorMessage('خطأ غير متوقع', message);
  } else {
    showErrorMessage('خطأ غير متوقع', message);
  }
  
  return true; // منع ظهور رسالة الخطأ الافتراضية
};
