/**
 * ui.js - مدير واجهة المستخدم
 * يتعامل مع عرض وتحديث واجهة المستخدم وتفاعلات المستخدم
 */

class UIManager {
  constructor(dataManager, exportManager, aiManager, chartsManager) {
    this.dataManager = dataManager;
    this.exportManager = exportManager;
    this.aiManager = aiManager;
    this.chartsManager = chartsManager;
    
    this.currentView = 'main'; // main, expenses, settings, stats
    this.currentProjectId = null;
    this.themeColors = this.getThemeColors();
    
    // تهيئة مستمعي الأحداث
    this.initEventListeners();
  }
  
  /**
   * تهيئة مستمعي الأحداث
   */
  initEventListeners() {
    // مستمع لتغييرات الاتصال
    window.addEventListener('online', () => this.updateConnectionStatus(true));
    window.addEventListener('offline', () => this.updateConnectionStatus(false));
    
    // مستمع للإشعارات
    window.addEventListener('app-notification', (event) => {
      this.showNotification(event.detail.title, event.detail.body);
    });
    
    // مستمع لتغيير حجم النافذة
    window.addEventListener('resize', this.handleResize.bind(this));
    
    // مستمع لتغييرات السمة
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', this.updateSystemTheme.bind(this));
  }
  
  /**
   * تحديث حالة الاتصال
   */
  updateConnectionStatus(isOnline) {
    const statusElement = document.getElementById('connection-status');
    if (statusElement) {
      statusElement.className = isOnline ? 'status-online' : 'status-offline';
      statusElement.textContent = isOnline ? 'متصل' : 'غير متصل';
    }
    
    if (!isOnline) {
      this.showNotification('أنت الآن غير متصل', 'سيتم حفظ التغييرات محلياً ومزامنتها عند استعادة الاتصال');
    }
  }
  
  /**
   * التعامل مع تغيير حجم النافذة
   */
  handleResize() {
    // تحديث الرسوم البيانية إذا كانت موجودة
    if (this.currentView === 'stats' && this.currentProjectId) {
      this.refreshCharts();
    }
  }
  
  /**
   * تحديث سمة النظام
   */
  updateSystemTheme(e) {
    const settings = this.dataManager.getSettings();
    if (settings.followSystemTheme) {
      const isDark = e.matches;
      this.setTheme(isDark ? 'dark' : 'light');
    }
  }
  
  /**
   * تهيئة واجهة المستخدم
   */
  async init() {
    try {
      // تحميل البيانات
      await this.dataManager.loadData();
      
      // تطبيق الإعدادات
      this.applySettings();
      
      // عرض الصفحة الرئيسية
      this.showMainPage();
      
      // إخفاء شاشة التحميل
      this.hideLoadingScreen();
      
      // طلب إذن الإشعارات
      this.requestNotificationPermission();
      
      console.log('تم تهيئة واجهة المستخدم بنجاح');
      return true;
    } catch (error) {
      console.error('خطأ في تهيئة واجهة المستخدم:', error);
      this.showErrorMessage('حدث خطأ أثناء تهيئة التطبيق', error.message);
      return false;
    }
  }
  
  /**
   * إخفاء شاشة التحميل
   */
  hideLoadingScreen() {
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
      loadingScreen.classList.add('fade-out');
      setTimeout(() => {
        loadingScreen.style.display = 'none';
      }, 500);
    }
  }
  
  /**
   * طلب إذن الإشعارات
   */
  requestNotificationPermission() {
    if ('Notification' in window && Notification.permission !== 'granted' && Notification.permission !== 'denied') {
      Notification.requestPermission();
    }
  }
  
  /**
   * تطبيق إعدادات المستخدم
   */
  applySettings() {
    const settings = this.dataManager.getSettings();
    
    // تطبيق السمة
    this.setTheme(settings.darkMode ? 'dark' : 'light');
    
    // تطبيق النمط
    this.setStyle(settings.selectedStyle || 'default');
    
    // تطبيق حجم الخط
    this.setFontSize(settings.fontSize || 100);
    
    // تحديث حالة الاتصال
    this.updateConnectionStatus(navigator.onLine);
  }
  
  /**
   * تعيين السمة (فاتح/داكن)
   */
  setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    
    // تحديث لون الشريط العلوي في الأجهزة المحمولة
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      const themeColors = this.getThemeColors();
      metaThemeColor.setAttribute('content', theme === 'dark' ? themeColors.dark : themeColors.light);
    }
    
    // تحديث الإعدادات
    const settings = this.dataManager.getSettings();
    settings.darkMode = theme === 'dark';
    this.dataManager.saveSettings(settings);
  }
  
  /**
   * تعيين النمط
   */
  setStyle(style) {
    document.documentElement.setAttribute('data-style', style);
    
    // تحديث الإعدادات
    const settings = this.dataManager.getSettings();
    settings.selectedStyle = style;
    this.dataManager.saveSettings(settings);
  }
  
  /**
   * تعيين حجم الخط
   */
  setFontSize(size) {
    document.documentElement.style.fontSize = `${size}%`;
    
    // تحديث الإعدادات
    const settings = this.dataManager.getSettings();
    settings.fontSize = size;
    this.dataManager.saveSettings(settings);
  }
  
  /**
   * الحصول على ألوان السمة
   */
  getThemeColors() {
    return {
      light: '#2196F3', // لون السمة الفاتحة
      dark: '#121212'   // لون السمة الداكنة
    };
  }
  
  /**
   * عرض الصفحة الرئيسية
   */
  showMainPage() {
    this.currentView = 'main';
    this.currentProjectId = null;
    
    // الحصول على عنصر الصفحة الرئيسية
    const mainPage = document.getElementById('mainPage');
    const expensesPage = document.getElementById('expensesPage');
    
    // إخفاء الصفحات الأخرى
    if (expensesPage) expensesPage.style.display = 'none';
    
    // عرض الصفحة الرئيسية
    if (mainPage) {
      mainPage.style.display = 'block';
      
      // تحديث محتوى الصفحة الرئيسية
      this.updateMainPageContent();
    }
    
    // تحديث زر الإضافة العائم
    this.updateFloatingButton('add-project');
    
    // تحديث العنوان
    document.title = 'إدارة مصروفات المشاريع';
  }
  
  /**
   * تحديث محتوى الصفحة الرئيسية
   */
  updateMainPageContent() {
    const mainPage = document.getElementById('mainPage');
    if (!mainPage) return;
    
    // الحصول على المشاريع
    const projects = this.dataManager.getProjects();
    
    // إنشاء ملخص الإحصائيات
    const stats = this.calculateOverallStats(projects);
    
    // إنشاء محتوى الصفحة الرئيسية
    let content = `
      <div class="welcome-card card glass-card">
        <h2>مرحباً بك في تطبيق إدارة مصروفات المشاريع</h2>
        <p>يمكنك إدارة مشاريعك ومصروفاتها بسهولة وكفاءة</p>
      </div>
      
      <div class="stats-summary">
        <div class="stat-item">
          <div class="stat-icon">📊</div>
          <div class="stat-title">عدد المشاريع</div>
          <div class="stat-value">${stats.projectCount}</div>
        </div>
        
        <div class="stat-item">
          <div class="stat-icon">💰</div>
          <div class="stat-title">إجمالي رأس المال</div>
          <div class="stat-value">${stats.totalCapital.toFixed(2)} ريال</div>
        </div>
        
        <div class="stat-item">
          <div class="stat-icon">💸</div>
          <div class="stat-title">إجمالي المصروفات</div>
          <div class="stat-value">${stats.totalExpenses.toFixed(2)} ريال</div>
        </div>
      </div>
    `;
    
    // إضافة قسم المشاريع
    content += '<h3>المشاريع</h3>';
    
    if (projects.length === 0) {
      content += `
        <div class="empty-state card">
          <div class="empty-icon">📝</div>
          <h3>لا توجد مشاريع</h3>
          <p>انقر على زر الإضافة لإنشاء مشروع جديد</p>
        </div>
      `;
    } else {
      content += '<div class="projects-grid">';
      
      // إنشاء بطاقات المشاريع
      projects.forEach(project => {
        const projectExpenses = this.dataManager.getExpenses(project.id);
        const totalCapital = this.calculateTotalCapital(projectExpenses);
        const totalExpenses = this.calculateTotalExpenses(projectExpenses);
        const remaining = totalCapital - totalExpenses;
        const utilizationRate = totalCapital > 0 ? (totalExpenses / totalCapital) * 100 : 0;
        
        content += `
          <div class="project-card card" data-project-id="${project.id}">
            <div class="project-header">
              <h3>${project.name}</h3>
            </div>
            <div class="project-body">
              <p>تاريخ البدء: ${this.formatDate(project.date)}</p>
              <p>رأس المال: ${totalCapital.toFixed(2)} ريال</p>
              <p>المصروفات: ${totalExpenses.toFixed(2)} ريال</p>
              <p>المتبقي: ${remaining.toFixed(2)} ريال</p>
              <div class="progress-bar">
                <div class="progress" style="width: ${Math.min(100, utilizationRate)}%;"></div>
              </div>
              <p class="utilization-rate">${utilizationRate.toFixed(1)}%</p>
            </div>
            <div class="project-footer">
              <button class="project-btn view" onclick="app.ui.showExpensesPage('${project.id}')">عرض</button>
              <button class="project-btn stats" onclick="app.ui.showStatsPage('${project.id}')">إحصائيات</button>
              <button class="project-btn delete" onclick="app.ui.confirmDeleteProject('${project.id}')">حذف</button>
            </div>
          </div>
        `;
      });
      
      content += '</div>';
    }
    
    // إضافة حقوق النشر
    content += `
      <div class="copyright">
        <span>© حقوق النشر محفوظة لـ hashem almatariy - 774889958</span>
      </div>
    `;
    
    // تحديث المحتوى
    mainPage.innerHTML = content;
    
    // إضافة مستمعي الأحداث
    this.addMainPageEventListeners();
  }
  
  /**
   * إضافة مستمعي الأحداث للصفحة الرئيسية
   */
  addMainPageEventListeners() {
    // يمكن إضافة مستمعي أحداث إضافية هنا إذا لزم الأمر
  }
  
  /**
   * عرض صفحة المصروفات
   */
  showExpensesPage(projectId) {
    this.currentView = 'expenses';
    this.currentProjectId = projectId;
    
    // الحصول على عناصر الصفحات
    const mainPage = document.getElementById('mainPage');
    const expensesPage = document.getElementById('expensesPage');
    
    // إخفاء الصفحات الأخرى
    if (mainPage) mainPage.style.display = 'none';
    
    // عرض صفحة المصروفات
    if (expensesPage) {
      expensesPage.style.display = 'block';
      
      // تحديث محتوى صفحة المصروفات
      this.updateExpensesPageContent(projectId);
    }
    
    // تحديث زر الإضافة العائم
    this.updateFloatingButton('add-expense');
    
    // تحديث العنوان
    const project = this.dataManager.getProject(projectId);
    document.title = `مصروفات - ${project ? project.name : 'المشروع'}`;
  }
  
  /**
   * تحديث محتوى صفحة المصروفات
   */
  updateExpensesPageContent(projectId) {
    const expensesPage = document.getElementById('expensesPage');
    if (!expensesPage) return;
    
    // الحصول على بيانات المشروع
    const project = this.dataManager.getProject(projectId);
    if (!project) {
      expensesPage.innerHTML = '<div class="card error-card">المشروع غير موجود</div>';
      return;
    }
    
    const expenses = this.dataManager.getExpenses(projectId);
    
    // حساب الإحصائيات
    const totalCapital = this.calculateTotalCapital(expenses);
    const totalExpenses = this.calculateTotalExpenses(expenses);
    const remaining = totalCapital - totalExpenses;
    
    // إنشاء محتوى صفحة المصروفات
    let content = `
      <button class="back-btn" onclick="app.ui.showMainPage()">
        <i class="icon">←</i> العودة للصفحة الرئيسية
      </button>
      
      <div class="card project-details-card">
        <h2>${project.name}</h2>
        <p>تاريخ البدء: ${this.formatDate(project.date)}</p>
        
        <div class="summary card">
          <div class="summary-item capital">
            <span>رأس المال:</span>
            <span>${totalCapital.toFixed(2)} ريال</span>
          </div>
          <div class="summary-item expenses">
            <span>المصروفات:</span>
            <span>${totalExpenses.toFixed(2)} ريال</span>
          </div>
          <div class="summary-item remaining">
            <span>المتبقي:</span>
            <span>${remaining.toFixed(2)} ريال</span>
          </div>
        </div>
        
        <div class="actions-bar">
          <button class="export-btn" onclick="app.ui.showExportOptions('${projectId}')">
            <i class="icon">📤</i> تصدير
          </button>
          <button class="stats-btn" onclick="app.ui.showStatsPage('${projectId}')">
            <i class="icon">📊</i> إحصائيات
          </button>
        </div>
      </div>
      
      <div class="card">
        <h3>المعاملات</h3>
    `;
    
    if (expenses.length === 0) {
      content += `
        <div class="empty-state">
          <div class="empty-icon">💸</div>
          <h3>لا توجد معاملات</h3>
          <p>انقر على زر الإضافة لإضافة معاملة جديدة</p>
        </div>
      `;
    } else {
      // ترتيب المصروفات حسب التاريخ (الأحدث أولاً)
      const sortedExpenses = [...expenses].sort((a, b) => new Date(b.date) - new Date(a.date));
      
      // تجميع المصروفات حسب التاريخ
      const expensesByDate = {};
      sortedExpenses.forEach(expense => {
        const date = expense.date.split('T')[0]; // استخراج التاريخ فقط
        if (!expensesByDate[date]) {
          expensesByDate[date] = [];
        }
        expensesByDate[date].push(expense);
      });
      
      // إنشاء جدول المصروفات مجمعة حسب التاريخ
      Object.keys(expensesByDate).sort((a, b) => new Date(b) - new Date(a)).forEach(date => {
        const dayExpenses = expensesByDate[date];
        
        content += `
          <div class="day-frame">
            <div class="day-frame-content">
              <div class="day-frame-date">${this.formatDate(date)}</div>
              <table id="entriesTable">
                <tr>
                  <th>النوع</th>
                  <th>المبلغ</th>
                  <th>الوصف</th>
                  <th>الإجراءات</th>
                </tr>
        `;
        
        dayExpenses.forEach(expense => {
          content += `
            <tr>
              <td>${this.getExpenseTypeName(expense.type)}</td>
              <td>${parseFloat(expense.amount).toFixed(2)} ريال</td>
              <td>${expense.desc || '-'}</td>
              <td>
                <button class="edit-btn" onclick="app.ui.showEditExpenseModal('${projectId}', '${expense.id}')">تعديل</button>
                <button class="del-btn" onclick="app.ui.confirmDeleteExpense('${projectId}', '${expense.id}')">حذف</button>
              </td>
            </tr>
          `;
        });
        
        content += `
              </table>
            </div>
          </div>
        `;
      });
    }
    
    content += `
      </div>
      
      <div class="copyright">
        <span>© حقوق النشر محفوظة لـ hashem almatariy - 774889958</span>
      </div>
    `;
    
    // تحديث المحتوى
    expensesPage.innerHTML = content;
    
    // إضافة مستمعي الأحداث
    this.addExpensesPageEventListeners();
  }
  
  /**
   * إضافة مستمعي الأحداث لصفحة المصروفات
   */
  addExpensesPageEventListeners() {
    // يمكن إضافة مستمعي أحداث إضافية هنا إذا لزم الأمر
  }
  
  /**
   * عرض صفحة الإحصائيات
   */
  showStatsPage(projectId) {
    this.currentView = 'stats';
    this.currentProjectId = projectId;
    
    // الحصول على عناصر الصفحات
    const mainPage = document.getElementById('mainPage');
    const expensesPage = document.getElementById('expensesPage');
    
    // إخفاء الصفحات الأخرى
    if (mainPage) mainPage.style.display = 'none';
    if (expensesPage) expensesPage.style.display = 'none';
    
    // إنشاء صفحة الإحصائيات إذا لم تكن موجودة
    let statsPage = document.getElementById('statsPage');
    if (!statsPage) {
      statsPage = document.createElement('div');
      statsPage.id = 'statsPage';
      document.querySelector('.container').appendChild(statsPage);
    }
    
    // عرض صفحة الإحصائيات
    statsPage.style.display = 'block';
    
    // تحديث محتوى صفحة الإحصائيات
    this.updateStatsPageContent(projectId);
    
    // تحديث زر الإضافة العائم
    this.updateFloatingButton('none');
    
    // تحديث العنوان
    const project = this.dataManager.getProject(projectId);
    document.title = `إحصائيات - ${project ? project.name : 'المشروع'}`;
  }
  
  /**
   * تحديث محتوى صفحة الإحصائيات
   */
  async updateStatsPageContent(projectId) {
    const statsPage = document.getElementById('statsPage');
    if (!statsPage) return;
    
    // الحصول على بيانات المشروع
    const project = this.dataManager.getProject(projectId);
    if (!project) {
      statsPage.innerHTML = '<div class="card error-card">المشروع غير موجود</div>';
      return;
    }
    
    const expenses = this.dataManager.getExpenses(projectId);
    
    // إنشاء محتوى صفحة الإحصائيات
    let content = `
      <button class="back-btn" onclick="app.ui.showExpensesPage('${projectId}')">
        <i class="icon">←</i> العودة لصفحة المصروفات
      </button>
      
      <div class="card">
        <h2>إحصائيات المشروع: ${project.name}</h2>
        
        <div class="tabs">
          <button class="tab-btn active" data-tab="charts">الرسوم البيانية</button>
          <button class="tab-btn" data-tab="predictions">التنبؤات</button>
          <button class="tab-btn" data-tab="analysis">التحليل</button>
          <button class="tab-btn" data-tab="suggestions">اقتراحات التوفير</button>
        </div>
        
        <div class="tab-content" id="charts-tab">
          <div class="chart-container">
            <h3>المصروفات حسب التاريخ</h3>
            <div id="expensesChart" style="height: 300px;"></div>
          </div>
          
          <div class="chart-container">
            <h3>توزيع المصروفات</h3>
            <div id="distributionChart" style="height: 300px;"></div>
          </div>
        </div>
        
        <div class="tab-content" id="predictions-tab" style="display: none;">
          <div class="card glass-card">
            <h3>التنبؤ بالمصروفات المستقبلية</h3>
            <p>يستخدم التطبيق الذكاء الاصطناعي للتنبؤ بالمصروفات المستقبلية بناءً على أنماط الإنفاق السابقة.</p>
            
            <div class="prediction-controls">
              <button id="train-model-btn" class="neon-button">تدريب النموذج</button>
              <button id="predict-btn" class="neon-button" disabled>التنبؤ بالمصروفات</button>
            </div>
            
            <div id="prediction-results" style="display: none;">
              <h4>نتائج التنبؤ</h4>
              <div id="prediction-chart" style="height: 300px;"></div>
              <div id="prediction-table"></div>
            </div>
            
            <div id="prediction-loading" style="display: none;">
              <div class="loading-spinner"></div>
              <p>جاري تدريب النموذج وإجراء التنبؤات...</p>
            </div>
          </div>
        </div>
        
        <div class="tab-content" id="analysis-tab" style="display: none;">
          <div class="card glass-card">
            <h3>تحليل أنماط الإنفاق</h3>
            <div id="trends-analysis"></div>
          </div>
          
          <div class="card glass-card">
            <h3>اكتشاف المصروفات غير العادية</h3>
            <div id="anomalies-analysis"></div>
          </div>
        </div>
        
        <div class="tab-content" id="suggestions-tab" style="display: none;">
          <div class="card glass-card">
            <h3>اقتراحات لتوفير المال</h3>
            <div id="saving-suggestions"></div>
          </div>
        </div>
      </div>
      
      <div class="copyright">
        <span>© حقوق النشر محفوظة لـ hashem almatariy - 774889958</span>
      </div>
    `;
    
    // تحديث المحتوى
    statsPage.innerHTML = content;
    
    // إضافة مستمعي الأحداث
    this.addStatsPageEventListeners(projectId);
    
    // إنشاء الرسوم البيانية
    this.createStatsCharts(projectId);
    
    // تحليل أنماط الإنفاق
    this.analyzeExpenseTrends(projectId);
    
    // اكتشاف المصروفات غير العادية
    this.detectAnomalies(projectId);
    
    // توليد اقتراحات التوفير
    this.generateSavingSuggestions(projectId);
  }
  
  /**
   * إضافة مستمعي الأحداث لصفحة الإحصائيات
   */
  addStatsPageEventListeners(projectId) {
    // مستمعي أحداث التبويبات
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        // إزالة الفئة النشطة من جميع الأزرار
        tabButtons.forEach(btn => btn.classList.remove('active'));
        
        // إضافة الفئة النشطة للزر المنقور
        button.classList.add('active');
        
        // إخفاء جميع محتويات التبويبات
        document.querySelectorAll('.tab-content').forEach(content => {
          content.style.display = 'none';
        });
        
        // عرض محتوى التبويب المحدد
        const tabId = button.getAttribute('data-tab');
        document.getElementById(`${tabId}-tab`).style.display = 'block';
        
        // تحديث الرسوم البيانية إذا كان التبويب هو الرسوم البيانية
        if (tabId === 'charts') {
          this.refreshCharts();
        }
      });
    });
    
    // مستمع حدث زر تدريب النموذج
    const trainModelBtn = document.getElementById('train-model-btn');
    if (trainModelBtn) {
      trainModelBtn.addEventListener('click', async () => {
        try {
          // عرض شاشة التحميل
          document.getElementById('prediction-loading').style.display = 'block';
          
          // تدريب النموذج
          await this.aiManager.trainModel(projectId);
          
          // تمكين زر التنبؤ
          document.getElementById('predict-btn').disabled = false;
          
          // إخفاء شاشة التحميل
          document.getElementById('prediction-loading').style.display = 'none';
          
          // عرض رسالة نجاح
          this.showNotification('تم تدريب النموذج بنجاح', 'يمكنك الآن التنبؤ بالمصروفات المستقبلية');
        } catch (error) {
          // إخفاء شاشة التحميل
          document.getElementById('prediction-loading').style.display = 'none';
          
          // عرض رسالة خطأ
          this.showErrorMessage('خطأ في تدريب النموذج', error.message);
        }
      });
    }
    
    // مستمع حدث زر التنبؤ
    const predictBtn = document.getElementById('predict-btn');
    if (predictBtn) {
      predictBtn.addEventListener('click', async () => {
        try {
          // عرض شاشة التحميل
          document.getElementById('prediction-loading').style.display = 'block';
          
          // التنبؤ بالمصروفات المستقبلية
          const predictions = await this.aiManager.predictFutureExpenses(projectId, 7);
          
          // عرض نتائج التنبؤ
          this.showPredictionResults(projectId, predictions);
          
          // إخفاء شاشة التحميل
          document.getElementById('prediction-loading').style.display = 'none';
        } catch (error) {
          // إخفاء شاشة التحميل
          document.getElementById('prediction-loading').style.display = 'none';
          
          // عرض رسالة خطأ
          this.showErrorMessage('خطأ في التنبؤ بالمصروفات', error.message);
        }
      });
    }
  }
  
  /**
   * إنشاء الرسوم البيانية لصفحة الإحصائيات
   */
  createStatsCharts(projectId) {
    try {
      // إنشاء رسم بياني للمصروفات حسب التاريخ
      this.chartsManager.createExpensesByDateChart(projectId, 'expensesChart');
      
      // إنشاء رسم بياني دائري لتوزيع المصروفات
      this.chartsManager.createExpenseDistributionChart(projectId, 'distributionChart');
    } catch (error) {
      console.error('خطأ في إنشاء الرسوم البيانية:', error);
      this.showErrorMessage('خطأ في إنشاء الرسوم البيانية', error.message);
    }
  }
  
  /**
   * تحديث الرسوم البيانية
   */
  refreshCharts() {
    try {
      // تدمير الرسوم البيانية الحالية
      this.chartsManager.destroyChart('expensesChart');
      this.chartsManager.destroyChart('distributionChart');
      
      // إعادة إنشاء الرسوم البيانية
      if (this.currentProjectId) {
        this.createStatsCharts(this.currentProjectId);
      }
    } catch (error) {
      console.error('خطأ في تحديث الرسوم البيانية:', error);
    }
  }
  
  /**
   * تحليل أنماط الإنفاق
   */
  async analyzeExpenseTrends(projectId) {
    try {
      const trendsContainer = document.getElementById('trends-analysis');
      if (!trendsContainer) return;
      
      // عرض شاشة التحميل
      trendsContainer.innerHTML = '<div class="loading-spinner"></div>';
      
      // تحليل أنماط الإنفاق
      const trends = await this.aiManager.analyzeExpenseTrends(projectId);
      
      // إنشاء محتوى التحليل
      let content = `
        <div class="analysis-result">
          <div class="analysis-header">
            <div class="analysis-icon ${trends.trend === 'تصاعدي' ? 'trend-up' : trends.trend === 'تنازلي' ? 'trend-down' : 'trend-stable'}">
              ${trends.trend === 'تصاعدي' ? '📈' : trends.trend === 'تنازلي' ? '📉' : '📊'}
            </div>
            <div class="analysis-title">
              <h4>الاتجاه العام للمصروفات: ${trends.trend}</h4>
              <p>معدل النمو: ${trends.growthRate}%</p>
            </div>
          </div>
          
          <div class="analysis-details">
            <p>متوسط المصروفات اليومية: ${trends.averageDailyExpense} ريال</p>
      `;
      
      if (trends.peakDays.length > 0) {
        content += `
          <div class="peak-days">
            <h4>أيام الذروة:</h4>
            <ul>
        `;
        
        trends.peakDays.forEach(day => {
          content += `
            <li>
              <span class="day-name">${day.dayName}</span>
              <span class="day-amount">${day.averageAmount} ريال</span>
              <span class="day-ratio">(${day.ratio}x المتوسط)</span>
            </li>
          `;
        });
        
        content += `
            </ul>
          </div>
        `;
      }
      
      content += `
          </div>
        </div>
      `;
      
      // تحديث المحتوى
      trendsContainer.innerHTML = content;
    } catch (error) {
      console.error('خطأ في تحليل أنماط الإنفاق:', error);
      
      const trendsContainer = document.getElementById('trends-analysis');
      if (trendsContainer) {
        trendsContainer.innerHTML = `
          <div class="error-message">
            <p>تعذر تحليل أنماط الإنفاق: ${error.message}</p>
          </div>
        `;
      }
    }
  }
  
  /**
   * اكتشاف المصروفات غير العادية
   */
  async detectAnomalies(projectId) {
    try {
      const anomaliesContainer = document.getElementById('anomalies-analysis');
      if (!anomaliesContainer) return;
      
      // عرض شاشة التحميل
      anomaliesContainer.innerHTML = '<div class="loading-spinner"></div>';
      
      // اكتشاف المصروفات غير العادية
      const anomalies = await this.aiManager.detectAnomalies(projectId);
      
      // إنشاء محتوى التحليل
      let content = `
        <div class="analysis-result">
          <div class="analysis-header">
            <div class="analysis-icon">🔍</div>
            <div class="analysis-title">
              <h4>المصروفات غير العادية</h4>
              <p>المتوسط: ${anomalies.mean} ريال | الانحراف المعياري: ${anomalies.stdDev} ريال</p>
            </div>
          </div>
      `;
      
      if (anomalies.anomalies.length === 0) {
        content += `
          <div class="analysis-details">
            <p>لم يتم اكتشاف مصروفات غير عادية.</p>
          </div>
        `;
      } else {
        content += `
          <div class="analysis-details">
            <p>تم اكتشاف ${anomalies.anomalies.length} مصروفات غير عادية:</p>
            <table class="anomalies-table">
              <tr>
                <th>التاريخ</th>
                <th>المبلغ</th>
                <th>الوصف</th>
                <th>درجة الشذوذ</th>
              </tr>
        `;
        
        anomalies.anomalies.forEach(anomaly => {
          content += `
            <tr>
              <td>${this.formatDate(anomaly.date)}</td>
              <td>${anomaly.amount.toFixed(2)} ريال</td>
              <td>${anomaly.desc || '-'}</td>
              <td>${anomaly.zScore}x</td>
            </tr>
          `;
        });
        
        content += `
            </table>
          </div>
        `;
      }
      
      content += `</div>`;
      
      // تحديث المحتوى
      anomaliesContainer.innerHTML = content;
    } catch (error) {
      console.error('خطأ في اكتشاف المصروفات غير العادية:', error);
      
      const anomaliesContainer = document.getElementById('anomalies-analysis');
      if (anomaliesContainer) {
        anomaliesContainer.innerHTML = `
          <div class="error-message">
            <p>تعذر اكتشاف المصروفات غير العادية: ${error.message}</p>
          </div>
        `;
      }
    }
  }
  
  /**
   * توليد اقتراحات التوفير
   */
  async generateSavingSuggestions(projectId) {
    try {
      const suggestionsContainer = document.getElementById('saving-suggestions');
      if (!suggestionsContainer) return;
      
      // عرض شاشة التحميل
      suggestionsContainer.innerHTML = '<div class="loading-spinner"></div>';
      
      // توليد اقتراحات التوفير
      const suggestions = await this.aiManager.generateSavingSuggestions(projectId);
      
      // إنشاء محتوى الاقتراحات
      let content = `
        <div class="suggestions-result">
          <div class="suggestions-header">
            <div class="suggestions-icon">💰</div>
            <div class="suggestions-title">
              <h4>اقتراحات لتوفير المال</h4>
              <p>التوفير المحتمل: ${suggestions.totalPotentialSaving} ريال</p>
            </div>
          </div>
          
          <div class="suggestions-list">
      `;
      
      if (suggestions.suggestions.length === 0) {
        content += `
          <div class="empty-suggestions">
            <p>لا توجد اقتراحات للتوفير حالياً.</p>
          </div>
        `;
      } else {
        suggestions.suggestions.forEach(suggestion => {
          content += `
            <div class="suggestion-card">
              <div class="suggestion-icon">${this.getSuggestionIcon(suggestion.type)}</div>
              <div class="suggestion-content">
                <h4>${suggestion.title}</h4>
                <p>${suggestion.description}</p>
                <div class="suggestion-saving">التوفير المحتمل: ${suggestion.potentialSaving} ريال</div>
              </div>
            </div>
          `;
        });
      }
      
      content += `
          </div>
        </div>
      `;
      
      // تحديث المحتوى
      suggestionsContainer.innerHTML = content;
    } catch (error) {
      console.error('خطأ في توليد اقتراحات التوفير:', error);
      
      const suggestionsContainer = document.getElementById('saving-suggestions');
      if (suggestionsContainer) {
        suggestionsContainer.innerHTML = `
          <div class="error-message">
            <p>تعذر توليد اقتراحات التوفير: ${error.message}</p>
          </div>
        `;
      }
    }
  }
  
  /**
   * الحصول على أيقونة الاقتراح
   */
  getSuggestionIcon(type) {
    switch (type) {
      case 'peak_days':
        return '📅';
      case 'anomalies':
        return '⚠️';
      case 'trend':
        return '📈';
      case 'distribution':
        return '📊';
      default:
        return '💡';
    }
  }
  
  /**
   * عرض نتائج التنبؤ
   */
  showPredictionResults(projectId, predictions) {
    const resultsContainer = document.getElementById('prediction-results');
    if (!resultsContainer) return;
    
    // عرض نتائج التنبؤ
    resultsContainer.style.display = 'block';
    
    // إنشاء رسم بياني للتنبؤ
    this.chartsManager.createExpensePredictionChart(projectId, 'prediction-chart', predictions.predictions);
    
    // إنشاء جدول التنبؤات
    const tableContainer = document.getElementById('prediction-table');
    if (tableContainer) {
      let tableContent = `
        <table class="prediction-table">
          <tr>
            <th>التاريخ</th>
            <th>المبلغ المتوقع</th>
          </tr>
      `;
      
      predictions.predictions.forEach(prediction => {
        tableContent += `
          <tr>
            <td>${this.formatDate(prediction.date)}</td>
            <td>${prediction.amount.toFixed(2)} ريال</td>
          </tr>
        `;
      });
      
      tableContent += `</table>`;
      
      tableContainer.innerHTML = tableContent;
    }
  }
  
  /**
   * عرض خيارات التصدير
   */
  showExportOptions(projectId) {
    // إنشاء مودال خيارات التصدير
    const modalId = 'exportOptionsModal';
    
    // التحقق من وجود المودال
    let modal = document.getElementById(modalId);
    if (!modal) {
      // إنشاء المودال
      modal = document.createElement('div');
      modal.id = modalId;
      modal.className = 'modal';
      document.body.appendChild(modal);
    }
    
    // إنشاء محتوى المودال
    modal.innerHTML = `
      <div class="modal-content">
        <h3>تصدير البيانات</h3>
        
        <div class="export-options">
          <div class="export-option" onclick="app.ui.exportToExcel('${projectId}')">
            <div class="export-icon">📊</div>
            <div class="export-title">تصدير إلى Excel</div>
            <div class="export-desc">تصدير بيانات المشروع إلى ملف Excel</div>
          </div>
          
          <div class="export-option" onclick="app.ui.exportToPDF('${projectId}')">
            <div class="export-icon">📄</div>
            <div class="export-title">تصدير إلى PDF</div>
            <div class="export-desc">تصدير بيانات المشروع إلى ملف PDF</div>
          </div>
        </div>
        
        <div class="export-options-advanced">
          <h4>خيارات متقدمة</h4>
          
          <div class="export-option-row">
            <label for="includeCharts">تضمين الرسوم البيانية</label>
            <label class="switch">
              <input type="checkbox" id="includeCharts" checked>
              <span class="slider"></span>
            </label>
          </div>
          
          <div class="export-option-row">
            <label for="includeStats">تضمين الإحصائيات</label>
            <label class="switch">
              <input type="checkbox" id="includeStats" checked>
              <span class="slider"></span>
            </label>
          </div>
          
          <div class="export-option-row">
            <label for="exportTheme">سمة التقرير</label>
            <select id="exportTheme">
              <option value="default">الافتراضية</option>
              <option value="modern">عصرية</option>
              <option value="minimal">بسيطة</option>
            </select>
          </div>
        </div>
        
        <button class="close-btn" onclick="app.ui.closeModal('${modalId}')">إغلاق</button>
      </div>
    `;
    
    // عرض المودال
    this.openModal(modalId);
  }
  
  /**
   * تصدير إلى Excel
   */
  async exportToExcel(projectId) {
    try {
      // الحصول على خيارات التصدير
      const includeCharts = document.getElementById('includeCharts').checked;
      const includeStats = document.getElementById('includeStats').checked;
      const theme = document.getElementById('exportTheme').value;
      
      // إغلاق مودال خيارات التصدير
      this.closeModal('exportOptionsModal');
      
      // عرض شاشة التحميل
      this.showLoadingOverlay('جاري تصدير البيانات إلى Excel...');
      
      // تصدير البيانات
      const result = await this.exportManager.exportProjectToExcel(projectId, {
        includeCharts,
        includeStats,
        theme
      });
      
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة نجاح
      this.showNotification('تم التصدير بنجاح', `تم تصدير البيانات إلى ملف Excel: ${result.fileName}`);
    } catch (error) {
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة خطأ
      this.showErrorMessage('خطأ في التصدير', error.message);
    }
  }
  
  /**
   * تصدير إلى PDF
   */
  async exportToPDF(projectId) {
    try {
      // الحصول على خيارات التصدير
      const includeCharts = document.getElementById('includeCharts').checked;
      const includeStats = document.getElementById('includeStats').checked;
      const theme = document.getElementById('exportTheme').value;
      
      // إغلاق مودال خيارات التصدير
      this.closeModal('exportOptionsModal');
      
      // عرض شاشة التحميل
      this.showLoadingOverlay('جاري تصدير البيانات إلى PDF...');
      
      // تصدير البيانات
      const result = await this.exportManager.exportProjectToPDF(projectId, {
        includeCharts,
        includeStats,
        theme
      });
      
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة نجاح
      this.showNotification('تم التصدير بنجاح', `تم تصدير البيانات إلى ملف PDF: ${result.fileName}`);
    } catch (error) {
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة خطأ
      this.showErrorMessage('خطأ في التصدير', error.message);
    }
  }
  
  /**
   * تحديث زر الإضافة العائم
   */
  updateFloatingButton(action) {
    const floatingBtn = document.getElementById('floatingBtn');
    if (!floatingBtn) return;
    
    switch (action) {
      case 'add-project':
        floatingBtn.innerHTML = '+';
        floatingBtn.title = 'إضافة مشروع جديد';
        floatingBtn.onclick = () => this.showAddProjectModal();
        floatingBtn.style.display = 'flex';
        break;
      
      case 'add-expense':
        floatingBtn.innerHTML = '+';
        floatingBtn.title = 'إضافة معاملة جديدة';
        floatingBtn.onclick = () => this.showAddExpenseModal(this.currentProjectId);
        floatingBtn.style.display = 'flex';
        break;
      
      case 'none':
      default:
        floatingBtn.style.display = 'none';
        break;
    }
  }
  
  /**
   * عرض مودال إضافة مشروع
   */
  showAddProjectModal() {
    // إنشاء مودال إضافة مشروع
    const modalId = 'addProjectModal';
    
    // التحقق من وجود المودال
    let modal = document.getElementById(modalId);
    if (!modal) {
      // إنشاء المودال
      modal = document.createElement('div');
      modal.id = modalId;
      modal.className = 'modal';
      document.body.appendChild(modal);
    }
    
    // تعيين تاريخ اليوم
    const today = new Date().toISOString().split('T')[0];
    
    // إنشاء محتوى المودال
    modal.innerHTML = `
      <div class="modal-content">
        <h3>إضافة مشروع جديد</h3>
        <input type="text" id="projectName" placeholder="اسم المشروع" autocomplete="off">
        <input type="date" id="projectDate" value="${today}">
        <button class="add-btn" onclick="app.ui.addProject()">إضافة</button>
        <button class="close-btn" onclick="app.ui.closeModal('${modalId}')">إلغاء</button>
      </div>
    `;
    
    // عرض المودال
    this.openModal(modalId);
    
    // تركيز حقل اسم المشروع
    setTimeout(() => {
      document.getElementById('projectName').focus();
    }, 100);
  }
  
  /**
   * إضافة مشروع جديد
   */
  async addProject() {
    try {
      // الحصول على بيانات المشروع
      const name = document.getElementById('projectName').value.trim();
      const date = document.getElementById('projectDate').value;
      
      // التحقق من صحة البيانات
      if (!name) {
        throw new Error('يرجى إدخال اسم المشروع');
      }
      
      if (!date) {
        throw new Error('يرجى تحديد تاريخ المشروع');
      }
      
      // إغلاق المودال
      this.closeModal('addProjectModal');
      
      // عرض شاشة التحميل
      this.showLoadingOverlay('جاري إضافة المشروع...');
      
      // إضافة المشروع
      const project = await this.dataManager.addProject({
        name,
        date
      });
      
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // تحديث الصفحة الرئيسية
      this.updateMainPageContent();
      
      // عرض رسالة نجاح
      this.showNotification('تم إضافة المشروع', `تم إضافة المشروع "${name}" بنجاح`);
      
      return project;
    } catch (error) {
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة خطأ
      this.showErrorMessage('خطأ في إضافة المشروع', error.message);
      
      return null;
    }
  }
  
  /**
   * تأكيد حذف مشروع
   */
  confirmDeleteProject(projectId) {
    // الحصول على بيانات المشروع
    const project = this.dataManager.getProject(projectId);
    if (!project) {
      this.showErrorMessage('خطأ', 'المشروع غير موجود');
      return;
    }
    
    // إنشاء مودال تأكيد الحذف
    const modalId = 'confirmDeleteProjectModal';
    
    // التحقق من وجود المودال
    let modal = document.getElementById(modalId);
    if (!modal) {
      // إنشاء المودال
      modal = document.createElement('div');
      modal.id = modalId;
      modal.className = 'modal';
      document.body.appendChild(modal);
    }
    
    // إنشاء محتوى المودال
    modal.innerHTML = `
      <div class="modal-content">
        <h3>تأكيد الحذف</h3>
        <p>هل أنت متأكد من حذف المشروع "${project.name}"؟</p>
        <p class="warning-text">سيتم حذف جميع المصروفات المرتبطة بهذا المشروع.</p>
        <div class="modal-actions">
          <button class="danger-btn" onclick="app.ui.deleteProject('${projectId}')">حذف</button>
          <button class="close-btn" onclick="app.ui.closeModal('${modalId}')">إلغاء</button>
        </div>
      </div>
    `;
    
    // عرض المودال
    this.openModal(modalId);
  }
  
  /**
   * حذف مشروع
   */
  async deleteProject(projectId) {
    try {
      // إغلاق مودال تأكيد الحذف
      this.closeModal('confirmDeleteProjectModal');
      
      // عرض شاشة التحميل
      this.showLoadingOverlay('جاري حذف المشروع...');
      
      // حذف المشروع
      const deletedProject = await this.dataManager.deleteProject(projectId);
      
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // تحديث الصفحة الرئيسية
      this.updateMainPageContent();
      
      // عرض رسالة نجاح
      this.showNotification('تم حذف المشروع', `تم حذف المشروع "${deletedProject.name}" بنجاح`);
      
      return true;
    } catch (error) {
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة خطأ
      this.showErrorMessage('خطأ في حذف المشروع', error.message);
      
      return false;
    }
  }
  
  /**
   * عرض مودال إضافة معاملة
   */
  showAddExpenseModal(projectId) {
    // التحقق من وجود المشروع
    const project = this.dataManager.getProject(projectId);
    if (!project) {
      this.showErrorMessage('خطأ', 'المشروع غير موجود');
      return;
    }
    
    // إنشاء مودال إضافة معاملة
    const modalId = 'addExpenseModal';
    
    // التحقق من وجود المودال
    let modal = document.getElementById(modalId);
    if (!modal) {
      // إنشاء المودال
      modal = document.createElement('div');
      modal.id = modalId;
      modal.className = 'modal';
      document.body.appendChild(modal);
    }
    
    // تعيين تاريخ اليوم
    const today = new Date().toISOString().split('T')[0];
    
    // إنشاء محتوى المودال
    modal.innerHTML = `
      <div class="modal-content">
        <h3>إضافة معاملة جديدة</h3>
        <select id="expenseType">
          <option value="capital">رأس مال</option>
          <option value="expense">مصروف</option>
        </select>
        <input type="date" id="expenseDate" value="${today}">
        <input type="number" id="expenseAmount" placeholder="المبلغ" autocomplete="off">
        <input type="text" id="expenseDesc" placeholder="الوصف (اختياري)" autocomplete="off">
        <button class="add-btn" onclick="app.ui.addExpense('${projectId}')">إضافة</button>
        <button class="close-btn" onclick="app.ui.closeModal('${modalId}')">إلغاء</button>
      </div>
    `;
    
    // عرض المودال
    this.openModal(modalId);
    
    // تركيز حقل المبلغ
    setTimeout(() => {
      document.getElementById('expenseAmount').focus();
    }, 100);
  }
  
  /**
   * إضافة معاملة جديدة
   */
  async addExpense(projectId) {
    try {
      // الحصول على بيانات المعاملة
      const type = document.getElementById('expenseType').value;
      const date = document.getElementById('expenseDate').value;
      const amount = parseFloat(document.getElementById('expenseAmount').value);
      const desc = document.getElementById('expenseDesc').value.trim();
      
      // التحقق من صحة البيانات
      if (isNaN(amount) || amount <= 0) {
        throw new Error('يرجى إدخال مبلغ صحيح');
      }
      
      if (!date) {
        throw new Error('يرجى تحديد تاريخ المعاملة');
      }
      
      // إغلاق المودال
      this.closeModal('addExpenseModal');
      
      // عرض شاشة التحميل
      this.showLoadingOverlay('جاري إضافة المعاملة...');
      
      // إضافة المعاملة
      const expense = await this.dataManager.addExpense(projectId, {
        type,
        date,
        amount,
        desc
      });
      
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // تحديث صفحة المصروفات
      this.updateExpensesPageContent(projectId);
      
      // عرض رسالة نجاح
      this.showNotification('تم إضافة المعاملة', `تم إضافة ${type === 'capital' ? 'رأس مال' : 'مصروف'} بقيمة ${amount} ريال بنجاح`);
      
      return expense;
    } catch (error) {
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة خطأ
      this.showErrorMessage('خطأ في إضافة المعاملة', error.message);
      
      return null;
    }
  }
  
  /**
   * عرض مودال تعديل معاملة
   */
  showEditExpenseModal(projectId, expenseId) {
    // الحصول على بيانات المعاملة
    const expense = this.dataManager.getExpense(projectId, expenseId);
    if (!expense) {
      this.showErrorMessage('خطأ', 'المعاملة غير موجودة');
      return;
    }
    
    // إنشاء مودال تعديل معاملة
    const modalId = 'editExpenseModal';
    
    // التحقق من وجود المودال
    let modal = document.getElementById(modalId);
    if (!modal) {
      // إنشاء المودال
      modal = document.createElement('div');
      modal.id = modalId;
      modal.className = 'modal';
      document.body.appendChild(modal);
    }
    
    // تنسيق التاريخ
    const date = expense.date.split('T')[0];
    
    // إنشاء محتوى المودال
    modal.innerHTML = `
      <div class="modal-content">
        <h3>تعديل المعاملة</h3>
        <select id="editExpenseType">
          <option value="capital" ${expense.type === 'capital' ? 'selected' : ''}>رأس مال</option>
          <option value="expense" ${expense.type === 'expense' ? 'selected' : ''}>مصروف</option>
        </select>
        <input type="date" id="editExpenseDate" value="${date}">
        <input type="number" id="editExpenseAmount" placeholder="المبلغ" value="${expense.amount}" autocomplete="off">
        <input type="text" id="editExpenseDesc" placeholder="الوصف (اختياري)" value="${expense.desc || ''}" autocomplete="off">
        <button class="add-btn" onclick="app.ui.updateExpense('${projectId}', '${expenseId}')">حفظ التعديلات</button>
        <button class="close-btn" onclick="app.ui.closeModal('${modalId}')">إلغاء</button>
      </div>
    `;
    
    // عرض المودال
    this.openModal(modalId);
  }
  
  /**
   * تحديث معاملة
   */
  async updateExpense(projectId, expenseId) {
    try {
      // الحصول على بيانات المعاملة
      const type = document.getElementById('editExpenseType').value;
      const date = document.getElementById('editExpenseDate').value;
      const amount = parseFloat(document.getElementById('editExpenseAmount').value);
      const desc = document.getElementById('editExpenseDesc').value.trim();
      
      // التحقق من صحة البيانات
      if (isNaN(amount) || amount <= 0) {
        throw new Error('يرجى إدخال مبلغ صحيح');
      }
      
      if (!date) {
        throw new Error('يرجى تحديد تاريخ المعاملة');
      }
      
      // إغلاق المودال
      this.closeModal('editExpenseModal');
      
      // عرض شاشة التحميل
      this.showLoadingOverlay('جاري تحديث المعاملة...');
      
      // تحديث المعاملة
      const updatedExpense = await this.dataManager.updateExpense(projectId, expenseId, {
        type,
        date,
        amount,
        desc
      });
      
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // تحديث صفحة المصروفات
      this.updateExpensesPageContent(projectId);
      
      // عرض رسالة نجاح
      this.showNotification('تم تحديث المعاملة', 'تم تحديث المعاملة بنجاح');
      
      return updatedExpense;
    } catch (error) {
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة خطأ
      this.showErrorMessage('خطأ في تحديث المعاملة', error.message);
      
      return null;
    }
  }
  
  /**
   * تأكيد حذف معاملة
   */
  confirmDeleteExpense(projectId, expenseId) {
    // الحصول على بيانات المعاملة
    const expense = this.dataManager.getExpense(projectId, expenseId);
    if (!expense) {
      this.showErrorMessage('خطأ', 'المعاملة غير موجودة');
      return;
    }
    
    // إنشاء مودال تأكيد الحذف
    const modalId = 'confirmDeleteExpenseModal';
    
    // التحقق من وجود المودال
    let modal = document.getElementById(modalId);
    if (!modal) {
      // إنشاء المودال
      modal = document.createElement('div');
      modal.id = modalId;
      modal.className = 'modal';
      document.body.appendChild(modal);
    }
    
    // إنشاء محتوى المودال
    modal.innerHTML = `
      <div class="modal-content">
        <h3>تأكيد الحذف</h3>
        <p>هل أنت متأكد من حذف ${expense.type === 'capital' ? 'رأس المال' : 'المصروف'} بقيمة ${expense.amount} ريال؟</p>
        <div class="modal-actions">
          <button class="danger-btn" onclick="app.ui.deleteExpense('${projectId}', '${expenseId}')">حذف</button>
          <button class="close-btn" onclick="app.ui.closeModal('${modalId}')">إلغاء</button>
        </div>
      </div>
    `;
    
    // عرض المودال
    this.openModal(modalId);
  }
  
  /**
   * حذف معاملة
   */
  async deleteExpense(projectId, expenseId) {
    try {
      // إغلاق مودال تأكيد الحذف
      this.closeModal('confirmDeleteExpenseModal');
      
      // عرض شاشة التحميل
      this.showLoadingOverlay('جاري حذف المعاملة...');
      
      // حذف المعاملة
      const deletedExpense = await this.dataManager.deleteExpense(projectId, expenseId);
      
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // تحديث صفحة المصروفات
      this.updateExpensesPageContent(projectId);
      
      // عرض رسالة نجاح
      this.showNotification('تم حذف المعاملة', 'تم حذف المعاملة بنجاح');
      
      return true;
    } catch (error) {
      // إخفاء شاشة التحميل
      this.hideLoadingOverlay();
      
      // عرض رسالة خطأ
      this.showErrorMessage('خطأ في حذف المعاملة', error.message);
      
      return false;
    }
  }
  
  /**
   * فتح مودال
   */
  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.style.display = 'flex';
      
      // إضافة فئة للتأثير الحركي
      setTimeout(() => {
        const modalContent = modal.querySelector('.modal-content');
        if (modalContent) {
          modalContent.classList.add('modal-show');
        }
      }, 10);
    }
  }
  
  /**
   * إغلاق مودال
   */
  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      // إزالة فئة التأثير الحركي
      const modalContent = modal.querySelector('.modal-content');
      if (modalContent) {
        modalContent.classList.remove('modal-show');
      }
      
      // إخفاء المودال بعد انتهاء التأثير الحركي
      setTimeout(() => {
        modal.style.display = 'none';
      }, 300);
    }
  }
  
  /**
   * عرض شاشة التحميل
   */
  showLoadingOverlay(message = 'جاري التحميل...') {
    // التحقق من وجود شاشة التحميل
    let loadingOverlay = document.getElementById('loadingOverlay');
    if (!loadingOverlay) {
      // إنشاء شاشة التحميل
      loadingOverlay = document.createElement('div');
      loadingOverlay.id = 'loadingOverlay';
      loadingOverlay.className = 'loading-overlay';
      loadingOverlay.innerHTML = `
        <div class="loading-content">
          <div class="loading-spinner"></div>
          <div class="loading-message">${message}</div>
        </div>
      `;
      document.body.appendChild(loadingOverlay);
    } else {
      // تحديث رسالة التحميل
      const loadingMessage = loadingOverlay.querySelector('.loading-message');
      if (loadingMessage) {
        loadingMessage.textContent = message;
      }
      
      // عرض شاشة التحميل
      loadingOverlay.style.display = 'flex';
    }
  }
  
  /**
   * إخفاء شاشة التحميل
   */
  hideLoadingOverlay() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
      loadingOverlay.style.display = 'none';
    }
  }
  
  /**
   * عرض إشعار
   */
  showNotification(title, message) {
    // التحقق من وجود حاوية الإشعارات
    let notificationsContainer = document.getElementById('notificationsContainer');
    if (!notificationsContainer) {
      // إنشاء حاوية الإشعارات
      notificationsContainer = document.createElement('div');
      notificationsContainer.id = 'notificationsContainer';
      notificationsContainer.className = 'notifications-container';
      document.body.appendChild(notificationsContainer);
    }
    
    // إنشاء الإشعار
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `
      <div class="notification-content">
        <div class="notification-title">${title}</div>
        <div class="notification-message">${message}</div>
      </div>
      <button class="notification-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    // إضافة الإشعار إلى الحاوية
    notificationsContainer.appendChild(notification);
    
    // إزالة الإشعار بعد 5 ثوانٍ
    setTimeout(() => {
      notification.classList.add('notification-hide');
      setTimeout(() => {
        notification.remove();
      }, 300);
    }, 5000);
  }
  
  /**
   * عرض رسالة خطأ
   */
  showErrorMessage(title, message) {
    // التحقق من وجود حاوية رسائل الخطأ
    let errorMessagesContainer = document.getElementById('errorMessagesContainer');
    if (!errorMessagesContainer) {
      // إنشاء حاوية رسائل الخطأ
      errorMessagesContainer = document.createElement('div');
      errorMessagesContainer.id = 'errorMessagesContainer';
      errorMessagesContainer.className = 'error-messages-container';
      document.body.appendChild(errorMessagesContainer);
    }
    
    // إنشاء رسالة الخطأ
    const errorMessage = document.createElement('div');
    errorMessage.className = 'error-message';
    errorMessage.innerHTML = `
      <div class="error-content">
        <div class="error-icon">⚠️</div>
        <div class="error-text">
          <div class="error-title">${title}</div>
          <div class="error-description">${message}</div>
        </div>
      </div>
      <button class="error-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    // إضافة رسالة الخطأ إلى الحاوية
    errorMessagesContainer.appendChild(errorMessage);
    
    // إزالة رسالة الخطأ بعد 8 ثوانٍ
    setTimeout(() => {
      errorMessage.classList.add('error-hide');
      setTimeout(() => {
        errorMessage.remove();
      }, 300);
    }, 8000);
  }
  
  /**
   * حساب إحصائيات عامة
   */
  calculateOverallStats(projects) {
    let projectCount = projects.length;
    let totalCapital = 0;
    let totalExpenses = 0;
    
    projects.forEach(project => {
      const expenses = this.dataManager.getExpenses(project.id);
      totalCapital += this.calculateTotalCapital(expenses);
      totalExpenses += this.calculateTotalExpenses(expenses);
    });
    
    return {
      projectCount,
      totalCapital,
      totalExpenses,
      remaining: totalCapital - totalExpenses
    };
  }
  
  /**
   * حساب إجمالي رأس المال
   */
  calculateTotalCapital(expenses) {
    return expenses
      .filter(expense => expense.type === 'capital')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
  }
  
  /**
   * حساب إجمالي المصروفات
   */
  calculateTotalExpenses(expenses) {
    return expenses
      .filter(expense => expense.type === 'expense')
      .reduce((total, expense) => total + parseFloat(expense.amount), 0);
  }
  
  /**
   * الحصول على اسم نوع المصروف
   */
  getExpenseTypeName(type) {
    const types = {
      'capital': 'رأس مال',
      'expense': 'مصروف'
    };
    
    return types[type] || type;
  }
  
  /**
   * تنسيق التاريخ
   */
  formatDate(dateString) {
    if (!dateString) return '';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('ar-SA');
    } catch (e) {
      return dateString;
    }
  }
}

// تصدير الفئة
window.UIManager = UIManager;
