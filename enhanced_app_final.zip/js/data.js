/**
 * data.js - مدير البيانات والتخزين المحلي
 * يتعامل مع تخزين واسترجاع البيانات، المزامنة، والنسخ الاحتياطي
 */

class DataManager {
  constructor() {
    // المتغيرات الرئيسية
    this.projects = [];
    this.expenses = {};
    this.settings = this.getDefaultSettings();
    this.dbPromise = null;
    this.isOnline = navigator.onLine;
    
    // مراقبة حالة الاتصال
    window.addEventListener('online', () => this.handleConnectionChange(true));
    window.addEventListener('offline', () => this.handleConnectionChange(false));
    
    // تهيئة قاعدة البيانات
    this.initDatabase();
  }
  
  /**
   * تهيئة قاعدة البيانات المحلية IndexedDB
   */
  async initDatabase() {
    if (!('indexedDB' in window)) {
      console.warn('متصفحك لا يدعم IndexedDB. سيتم استخدام localStorage كبديل.');
      return;
    }
    
    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open('ProjectExpensesDB', 1);
      
      request.onerror = (event) => {
        console.error('خطأ في فتح قاعدة البيانات:', event.target.error);
        reject(event.target.error);
      };
      
      request.onsuccess = (event) => {
        console.log('تم فتح قاعدة البيانات بنجاح');
        resolve(event.target.result);
      };
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        // إنشاء مخازن البيانات
        if (!db.objectStoreNames.contains('projects')) {
          db.createObjectStore('projects', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('expenses')) {
          db.createObjectStore('expenses', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('offlineChanges')) {
          db.createObjectStore('offlineChanges', { keyPath: 'id', autoIncrement: true });
        }
        
        console.log('تم تحديث بنية قاعدة البيانات');
      };
    });
  }
  
  /**
   * الحصول على الإعدادات الافتراضية
   */
  getDefaultSettings() {
    return {
      id: 'app-settings',
      darkMode: false,
      selectedStyle: 'default',
      fontSize: 100,
      budgetNotifications: true,
      dailyReminder: false,
      overBudgetAlert: true,
      reminderTime: '18:00',
      budgetThreshold: 80,
      autoBackup: false,
      backupFrequency: 'weekly',
      enablePredictiveAnalysis: false,
      enableAdvancedCharts: true,
      lastCloudSync: null,
      lastBackup: null
    };
  }
  
  /**
   * تحميل البيانات من التخزين المحلي
   */
  async loadData() {
    try {
      // محاولة تحميل البيانات من IndexedDB أولاً
      if (this.dbPromise) {
        const db = await this.dbPromise;
        await this.loadFromIndexedDB(db);
      } else {
        // استخدام localStorage كبديل
        this.loadFromLocalStorage();
      }
      
      console.log('تم تحميل البيانات بنجاح');
      return true;
    } catch (error) {
      console.error('خطأ في تحميل البيانات:', error);
      
      // محاولة استخدام localStorage كبديل في حالة فشل IndexedDB
      try {
        this.loadFromLocalStorage();
        return true;
      } catch (e) {
        console.error('فشل تحميل البيانات من localStorage أيضاً:', e);
        return false;
      }
    }
  }
  
  /**
   * تحميل البيانات من IndexedDB
   */
  async loadFromIndexedDB(db) {
    // تحميل المشاريع
    this.projects = await this.getAllFromStore(db, 'projects');
    
    // تحميل المصروفات
    const expensesArray = await this.getAllFromStore(db, 'expenses');
    this.expenses = {};
    expensesArray.forEach(item => {
      this.expenses[item.id] = item.data;
    });
    
    // تحميل الإعدادات
    const settingsArray = await this.getAllFromStore(db, 'settings');
    if (settingsArray.length > 0) {
      this.settings = settingsArray[0];
    }
  }
  
  /**
   * الحصول على جميع العناصر من مخزن معين
   */
  async getAllFromStore(db, storeName) {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  
  /**
   * تحميل البيانات من localStorage
   */
  loadFromLocalStorage() {
    // تحميل المشاريع
    const savedProjects = localStorage.getItem('projects');
    if (savedProjects) {
      this.projects = JSON.parse(savedProjects);
    }
    
    // تحميل المصروفات
    const savedExpenses = localStorage.getItem('expenses');
    if (savedExpenses) {
      this.expenses = JSON.parse(savedExpenses);
    }
    
    // تحميل الإعدادات
    const savedSettings = localStorage.getItem('settings');
    if (savedSettings) {
      this.settings = { ...this.settings, ...JSON.parse(savedSettings) };
    }
  }
  
  /**
   * حفظ البيانات
   */
  async saveData() {
    try {
      // محاولة حفظ البيانات في IndexedDB أولاً
      if (this.dbPromise) {
        const db = await this.dbPromise;
        await this.saveToIndexedDB(db);
      } else {
        // استخدام localStorage كبديل
        this.saveToLocalStorage();
      }
      
      console.log('تم حفظ البيانات بنجاح');
      return true;
    } catch (error) {
      console.error('خطأ في حفظ البيانات:', error);
      
      // محاولة استخدام localStorage كبديل في حالة فشل IndexedDB
      try {
        this.saveToLocalStorage();
        return true;
      } catch (e) {
        console.error('فشل حفظ البيانات في localStorage أيضاً:', e);
        return false;
      }
    }
  }
  
  /**
   * حفظ البيانات في IndexedDB
   */
  async saveToIndexedDB(db) {
    // حفظ المشاريع
    await this.clearAndSaveStore(db, 'projects', this.projects.map(project => ({
      id: project.id,
      ...project
    })));
    
    // حفظ المصروفات
    const expensesArray = Object.keys(this.expenses).map(key => ({
      id: key,
      data: this.expenses[key]
    }));
    await this.clearAndSaveStore(db, 'expenses', expensesArray);
    
    // حفظ الإعدادات
    await this.clearAndSaveStore(db, 'settings', [this.settings]);
    
    // إذا كان متصلاً بالإنترنت، مزامنة التغييرات المحلية
    if (this.isOnline) {
      await this.syncOfflineChanges(db);
    }
  }
  
  /**
   * مسح وحفظ مخزن بيانات
   */
  async clearAndSaveStore(db, storeName, items) {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      
      // مسح المخزن
      const clearRequest = store.clear();
      
      clearRequest.onsuccess = () => {
        // إضافة العناصر الجديدة
        let completed = 0;
        
        if (items.length === 0) {
          resolve();
          return;
        }
        
        items.forEach(item => {
          const addRequest = store.add(item);
          
          addRequest.onsuccess = () => {
            completed++;
            if (completed === items.length) {
              resolve();
            }
          };
          
          addRequest.onerror = (event) => {
            console.error(`خطأ في إضافة عنصر إلى ${storeName}:`, event.target.error);
            reject(event.target.error);
          };
        });
      };
      
      clearRequest.onerror = (event) => {
        console.error(`خطأ في مسح مخزن ${storeName}:`, event.target.error);
        reject(event.target.error);
      };
    });
  }
  
  /**
   * حفظ البيانات في localStorage
   */
  saveToLocalStorage() {
    try {
      localStorage.setItem('projects', JSON.stringify(this.projects));
      localStorage.setItem('expenses', JSON.stringify(this.expenses));
      localStorage.setItem('settings', JSON.stringify(this.settings));
    } catch (error) {
      if (error.name === 'QuotaExceededError') {
        throw new Error('مساحة التخزين المحلية ممتلئة. لا يمكن حفظ المزيد من البيانات.');
      } else {
        throw error;
      }
    }
  }
  
  /**
   * التعامل مع تغيير حالة الاتصال
   */
  async handleConnectionChange(isOnline) {
    this.isOnline = isOnline;
    
    if (isOnline) {
      console.log('تم استعادة الاتصال بالإنترنت. جاري مزامنة البيانات...');
      
      // مزامنة التغييرات المحلية مع الخادم
      if (this.dbPromise) {
        const db = await this.dbPromise;
        await this.syncOfflineChanges(db);
      }
      
      // إرسال إشعار للمستخدم
      this.showNotification('تم استعادة الاتصال', 'تمت مزامنة البيانات بنجاح');
      
      // تشغيل مزامنة الخلفية إذا كان مدعوماً
      if ('serviceWorker' in navigator && 'SyncManager' in window) {
        const registration = await navigator.serviceWorker.ready;
        try {
          await registration.sync.register('sync-expenses');
          await registration.sync.register('sync-projects');
        } catch (error) {
          console.error('فشل تسجيل مزامنة الخلفية:', error);
        }
      }
    } else {
      console.log('تم فقدان الاتصال بالإنترنت. سيتم تخزين التغييرات محلياً.');
      this.showNotification('أنت الآن غير متصل', 'سيتم حفظ التغييرات محلياً ومزامنتها عند استعادة الاتصال');
    }
  }
  
  /**
   * مزامنة التغييرات المحلية مع الخادم
   */
  async syncOfflineChanges(db) {
    const transaction = db.transaction('offlineChanges', 'readwrite');
    const store = transaction.objectStore('offlineChanges');
    const changes = await new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    
    if (changes.length === 0) {
      return;
    }
    
    console.log(`مزامنة ${changes.length} من التغييرات المحلية...`);
    
    // في تطبيق حقيقي، هنا ستقوم بإرسال التغييرات إلى الخادم
    // لكن في هذا المثال، سنفترض أن المزامنة نجحت
    
    // مسح التغييرات المحلية بعد المزامنة
    await new Promise((resolve, reject) => {
      const clearRequest = store.clear();
      clearRequest.onsuccess = () => resolve();
      clearRequest.onerror = () => reject(clearRequest.error);
    });
    
    // تحديث وقت آخر مزامنة
    this.settings.lastCloudSync = new Date().toISOString();
    await this.saveData();
    
    console.log('تمت مزامنة التغييرات المحلية بنجاح');
  }
  
  /**
   * تسجيل تغيير محلي للمزامنة لاحقاً
   */
  async recordOfflineChange(changeType, data) {
    if (!this.dbPromise) {
      return;
    }
    
    const db = await this.dbPromise;
    const transaction = db.transaction('offlineChanges', 'readwrite');
    const store = transaction.objectStore('offlineChanges');
    
    const change = {
      timestamp: new Date().toISOString(),
      type: changeType,
      data: data
    };
    
    return new Promise((resolve, reject) => {
      const request = store.add(change);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
  
  /**
   * إظهار إشعار للمستخدم
   */
  showNotification(title, body) {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body });
    } else if ('Notification' in window && Notification.permission !== 'denied') {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          new Notification(title, { body });
        }
      });
    }
    
    // إظهار إشعار داخل التطبيق أيضاً
    const event = new CustomEvent('app-notification', {
      detail: { title, body }
    });
    window.dispatchEvent(event);
  }
  
  /**
   * إضافة مشروع جديد
   */
  async addProject(project) {
    // إضافة معرف فريد ووقت الإنشاء
    const newProject = {
      ...project,
      id: this.generateUniqueId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    this.projects.push(newProject);
    await this.saveData();
    
    // تسجيل التغيير للمزامنة إذا كان غير متصل
    if (!this.isOnline) {
      await this.recordOfflineChange('add-project', newProject);
    }
    
    return newProject;
  }
  
  /**
   * تحديث مشروع
   */
  async updateProject(projectId, updates) {
    const index = this.projects.findIndex(p => p.id === projectId);
    if (index === -1) {
      throw new Error('المشروع غير موجود');
    }
    
    const updatedProject = {
      ...this.projects[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    this.projects[index] = updatedProject;
    await this.saveData();
    
    // تسجيل التغيير للمزامنة إذا كان غير متصل
    if (!this.isOnline) {
      await this.recordOfflineChange('update-project', updatedProject);
    }
    
    return updatedProject;
  }
  
  /**
   * حذف مشروع
   */
  async deleteProject(projectId) {
    const index = this.projects.findIndex(p => p.id === projectId);
    if (index === -1) {
      throw new Error('المشروع غير موجود');
    }
    
    const deletedProject = this.projects[index];
    this.projects.splice(index, 1);
    
    // حذف مصروفات المشروع
    const expenseKey = this.getExpenseKey(projectId);
    if (this.expenses[expenseKey]) {
      delete this.expenses[expenseKey];
    }
    
    await this.saveData();
    
    // تسجيل التغيير للمزامنة إذا كان غير متصل
    if (!this.isOnline) {
      await this.recordOfflineChange('delete-project', { id: projectId });
    }
    
    return deletedProject;
  }
  
  /**
   * الحصول على مفتاح المصروفات للمشروع
   */
  getExpenseKey(projectId) {
    return `expenses_${projectId}`;
  }
  
  /**
   * إضافة مصروف جديد
   */
  async addExpense(projectId, expense) {
    const expenseKey = this.getExpenseKey(projectId);
    
    // إنشاء مصفوفة المصروفات إذا لم تكن موجودة
    if (!this.expenses[expenseKey]) {
      this.expenses[expenseKey] = [];
    }
    
    // إضافة معرف فريد ووقت الإنشاء
    const newExpense = {
      ...expense,
      id: this.generateUniqueId(),
      projectId,
      createdAt: new Date().toISOString()
    };
    
    this.expenses[expenseKey].push(newExpense);
    await this.saveData();
    
    // تسجيل التغيير للمزامنة إذا كان غير متصل
    if (!this.isOnline) {
      await this.recordOfflineChange('add-expense', newExpense);
    }
    
    return newExpense;
  }
  
  /**
   * تحديث مصروف
   */
  async updateExpense(projectId, expenseId, updates) {
    const expenseKey = this.getExpenseKey(projectId);
    
    if (!this.expenses[expenseKey]) {
      throw new Error('المشروع ليس لديه مصروفات');
    }
    
    const index = this.expenses[expenseKey].findIndex(e => e.id === expenseId);
    if (index === -1) {
      throw new Error('المصروف غير موجود');
    }
    
    const updatedExpense = {
      ...this.expenses[expenseKey][index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    this.expenses[expenseKey][index] = updatedExpense;
    await this.saveData();
    
    // تسجيل التغيير للمزامنة إذا كان غير متصل
    if (!this.isOnline) {
      await this.recordOfflineChange('update-expense', updatedExpense);
    }
    
    return updatedExpense;
  }
  
  /**
   * حذف مصروف
   */
  async deleteExpense(projectId, expenseId) {
    const expenseKey = this.getExpenseKey(projectId);
    
    if (!this.expenses[expenseKey]) {
      throw new Error('المشروع ليس لديه مصروفات');
    }
    
    const index = this.expenses[expenseKey].findIndex(e => e.id === expenseId);
    if (index === -1) {
      throw new Error('المصروف غير موجود');
    }
    
    const deletedExpense = this.expenses[expenseKey][index];
    this.expenses[expenseKey].splice(index, 1);
    await this.saveData();
    
    // تسجيل التغيير للمزامنة إذا كان غير متصل
    if (!this.isOnline) {
      await this.recordOfflineChange('delete-expense', { id: expenseId, projectId });
    }
    
    return deletedExpense;
  }
  
  /**
   * الحصول على جميع المشاريع
   */
  getProjects() {
    return [...this.projects];
  }
  
  /**
   * الحصول على مشروع بواسطة المعرف
   */
  getProject(projectId) {
    return this.projects.find(p => p.id === projectId);
  }
  
  /**
   * الحصول على مصروفات مشروع
   */
  getExpenses(projectId) {
    const expenseKey = this.getExpenseKey(projectId);
    return this.expenses[expenseKey] ? [...this.expenses[expenseKey]] : [];
  }
  
  /**
   * الحصول على مصروف بواسطة المعرف
   */
  getExpense(projectId, expenseId) {
    const expenseKey = this.getExpenseKey(projectId);
    if (!this.expenses[expenseKey]) {
      return null;
    }
    return this.expenses[expenseKey].find(e => e.id === expenseId);
  }
  
  /**
   * حفظ الإعدادات
   */
  async saveSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    await this.saveData();
    return this.settings;
  }
  
  /**
   * الحصول على الإعدادات
   */
  getSettings() {
    return { ...this.settings };
  }
  
  /**
   * تصدير جميع البيانات كـ JSON
   */
  exportAllData() {
    return {
      projects: this.projects,
      expenses: this.expenses,
      settings: this.settings,
      exportDate: new Date().toISOString(),
      version: '2.0.0'
    };
  }
  
  /**
   * استيراد البيانات من JSON
   */
  async importData(jsonData) {
    try {
      const data = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;
      
      // التحقق من صحة البيانات
      if (!data.projects || !data.expenses) {
        throw new Error('بيانات غير صالحة للاستيراد');
      }
      
      // استيراد البيانات
      this.projects = data.projects;
      this.expenses = data.expenses;
      
      // دمج الإعدادات مع الحفاظ على الإعدادات الحالية
      if (data.settings) {
        this.settings = { ...this.settings, ...data.settings };
      }
      
      await this.saveData();
      return true;
    } catch (error) {
      console.error('خطأ في استيراد البيانات:', error);
      throw new Error('فشل استيراد البيانات: ' + error.message);
    }
  }
  
  /**
   * إنشاء نسخة احتياطية سحابية
   */
  async createCloudBackup() {
    // في تطبيق حقيقي، هنا ستقوم بإرسال البيانات إلى خدمة سحابية
    // لكن في هذا المثال، سنفترض أن النسخ الاحتياطي نجح
    
    this.settings.lastBackup = new Date().toISOString();
    await this.saveData();
    
    return {
      success: true,
      timestamp: this.settings.lastBackup
    };
  }
  
  /**
   * استعادة من نسخة احتياطية سحابية
   */
  async restoreFromCloud() {
    // في تطبيق حقيقي، هنا ستقوم بجلب البيانات من خدمة سحابية
    // لكن في هذا المثال، سنفترض أن الاستعادة نجحت
    
    // تحديث وقت آخر مزامنة
    this.settings.lastCloudSync = new Date().toISOString();
    await this.saveData();
    
    return {
      success: true,
      timestamp: this.settings.lastCloudSync
    };
  }
  
  /**
   * حذف جميع البيانات
   */
  async clearAllData() {
    // حفظ الإعدادات الحالية
    const currentSettings = { ...this.settings };
    
    // إعادة تعيين البيانات
    this.projects = [];
    this.expenses = {};
    this.settings = this.getDefaultSettings();
    
    // استعادة بعض الإعدادات المهمة
    this.settings.darkMode = currentSettings.darkMode;
    this.settings.selectedStyle = currentSettings.selectedStyle;
    this.settings.fontSize = currentSettings.fontSize;
    
    await this.saveData();
    
    // مسح قاعدة البيانات
    if (this.dbPromise) {
      const db = await this.dbPromise;
      await Promise.all([
        this.clearStore(db, 'projects'),
        this.clearStore(db, 'expenses'),
        this.clearStore(db, 'offlineChanges')
      ]);
      
      // حفظ الإعدادات المحدثة
      const transaction = db.transaction('settings', 'readwrite');
      const store = transaction.objectStore('settings');
      await new Promise((resolve, reject) => {
        const clearRequest = store.clear();
        clearRequest.onsuccess = () => {
          const addRequest = store.add(this.settings);
          addRequest.onsuccess = () => resolve();
          addRequest.onerror = () => reject(addRequest.error);
        };
        clearRequest.onerror = () => reject(clearRequest.error);
      });
    }
    
    return true;
  }
  
  /**
   * مسح مخزن بيانات
   */
  async clearStore(db, storeName) {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
  
  /**
   * إنشاء معرف فريد
   */
  generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  }
}

// تصدير الفئة
window.DataManager = DataManager;
